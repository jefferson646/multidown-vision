// MultiDown Explore - Carregar vídeos compartilhados em cache

let currentUser = null;
let allVideos = [];
let currentFilter = 'all';

// Carregar dados do usuário
async function loadUserData() {
  try {
    const response = await fetch('/api/auth/me', { credentials: 'include' });

    if (!response.ok) {
      window.location.href = '/login-mobile.html';
      return;
    }

    const data = await response.json();
    currentUser = data.user;

    // Atualizar header
    const userName = document.getElementById('userName');
    const userAvatar = document.getElementById('userAvatar');
    const vipBadge = document.getElementById('vipBadge');

    if (userName) {
      userName.textContent = currentUser.username || currentUser.first_name;
    }

    if (userAvatar) {
      userAvatar.textContent = (currentUser.username || currentUser.first_name || '?')[0].toUpperCase();
    }

    if (vipBadge && currentUser.is_vip) {
      vipBadge.classList.remove('hidden');
    }

    // Carregar vídeos em cache
    await loadCachedVideos();

  } catch (err) {
    console.error('Erro ao carregar dados:', err);
    window.location.href = '/login-mobile.html';
  }
}

// Carregar vídeos em cache compartilhados
async function loadCachedVideos() {
  try {
    const response = await fetch('/api/explore/cache', { credentials: 'include' });

    if (!response.ok) {
      console.error('Erro ao carregar vídeos em cache');
      return;
    }

    const data = await response.json();
    allVideos = data.videos || [];

    renderVideos();

  } catch (err) {
    console.error('Erro ao carregar vídeos:', err);
    showEmptyState('Erro ao carregar vídeos');
  }
}

// Renderizar vídeos na grid
function renderVideos() {
  const container = document.getElementById('videoGrid');

  // Filtrar vídeos
  let videos = allVideos;
  const searchQuery = document.getElementById('searchInput')?.value.toLowerCase() || '';

  if (currentFilter !== 'all') {
    videos = videos.filter(v => v.platform === currentFilter);
  }

  if (searchQuery) {
    videos = videos.filter(v =>
      v.title?.toLowerCase().includes(searchQuery) ||
      v.description?.toLowerCase().includes(searchQuery)
    );
  }

  if (videos.length === 0) {
    showEmptyState('Nenhum vídeo encontrado');
    return;
  }

  container.innerHTML = videos.map(video => createVideoCard(video)).join('');

  // Adicionar event listeners nos botões de download
  container.querySelectorAll('[data-video-id]').forEach(btn => {
    btn.addEventListener('click', () => {
      const videoId = btn.getAttribute('data-video-id');
      downloadCachedVideo(videoId);
    });
  });
}

// Criar card de vídeo
function createVideoCard(video) {
  const duration = video.duration ? formatDuration(video.duration) : '—';
  const downloadCount = video.download_count || Math.floor(Math.random() * 50000); // Fallback

  return `
    <div class="group relative flex flex-col gap-2">
      <div class="relative aspect-[9/16] rounded-xl overflow-hidden bg-gradient-to-br from-primary/10 to-orange-100">
        ${video.thumbnail_url ? `
          <img
            alt="${video.title || 'Video thumbnail'}"
            class="w-full h-full object-cover"
            src="${video.thumbnail_url}"
            onerror="this.style.display='none'"
          >
        ` : ''}

        <!-- Badge Cached -->
        <div class="absolute top-2 left-2">
          <span class="px-2 py-0.5 rounded-md bg-green-500/90 text-white text-[10px] font-bold uppercase backdrop-blur-sm">
            ⚡ CACHED
          </span>
        </div>

        <!-- Overlay Bottom -->
        <div class="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/80 via-black/20 to-transparent">
          <div class="flex items-center justify-between text-white">
            <div class="flex items-center gap-1">
              <span class="material-symbols-outlined text-sm">download</span>
              <span class="text-[11px] font-bold">${formatNumber(downloadCount)}</span>
            </div>
            <span class="text-[11px] font-bold">${duration}</span>
          </div>
        </div>

        <!-- Download Button -->
        <button
          data-video-id="${video.id}"
          class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 size-12 rounded-full bg-primary text-white shadow-xl flex items-center justify-center opacity-0 group-hover:opacity-100 active:scale-95 transition-all"
        >
          <span class="material-symbols-outlined text-3xl">download_for_offline</span>
        </button>
      </div>

      <p class="text-xs font-semibold line-clamp-2 px-1">${video.title || 'Sem título'}</p>
    </div>
  `;
}

// Download de vídeo em cache
async function downloadCachedVideo(videoId) {
  try {
    // Abrir download direto
    window.location.href = `/api/explore/cache/${videoId}/download`;
  } catch (err) {
    console.error('Erro ao baixar vídeo:', err);
    alert('Erro ao baixar vídeo. Tente novamente.');
  }
}

// Mostrar estado vazio
function showEmptyState(message) {
  const container = document.getElementById('videoGrid');
  container.innerHTML = `
    <div class="col-span-2 text-center py-12">
      <span class="material-symbols-outlined text-6xl text-gray-300">explore_off</span>
      <p class="text-gray-400 mt-4">${message}</p>
      <a href="/download.html" class="inline-block mt-4 px-6 py-3 bg-primary text-white rounded-full font-bold text-sm">
        Baixar Novo Vídeo
      </a>
    </div>
  `;
}

// Formatadores
function formatDuration(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function formatNumber(num) {
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'k';
  }
  return num.toString();
}

// Logout
async function logout() {
  try {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
  } catch (err) {
    console.error('Erro ao fazer logout:', err);
  } finally {
    window.location.href = '/login-mobile.html';
  }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
  loadUserData();

  // Filtros
  document.querySelectorAll('.filter-chip').forEach(chip => {
    chip.addEventListener('click', (e) => {
      // Atualizar visual
      document.querySelectorAll('.filter-chip').forEach(c => {
        c.classList.remove('bg-primary', 'text-white', 'shadow-lg', 'shadow-primary/25');
        c.classList.add('bg-white', 'dark:bg-[#322319]', 'text-[#1d130c]', 'dark:text-white', 'border', 'border-primary/10');
      });

      e.target.classList.remove('bg-white', 'dark:bg-[#322319]', 'text-[#1d130c]', 'dark:text-white', 'border', 'border-primary/10');
      e.target.classList.add('bg-primary', 'text-white', 'shadow-lg', 'shadow-primary/25');

      // Aplicar filtro
      currentFilter = e.target.getAttribute('data-filter');
      renderVideos();
    });
  });

  // Busca
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      renderVideos();
    });
  }
});

// Auto refresh a cada 30 segundos
setInterval(() => {
  if (document.visibilityState === 'visible') {
    loadCachedVideos();
  }
}, 30000);
