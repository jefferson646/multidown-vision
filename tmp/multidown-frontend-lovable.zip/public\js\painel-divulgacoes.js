// ── State ──────────────────────────────────────────────────────────────────
let currentData = null;
let currentTemplate = 'padrao';
let currentPlatform = null;
let customTemplateImage = null;
let firstValueTracked = false;

// Lê csrf_token do cookie (mesmo padrão dos outros modais)
function getCsrfToken() {
  const match = document.cookie.match(/(?:^|;\s*)csrf_token=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : '';
}

function trackFirstValue(platform) {
  if (firstValueTracked || !window.funnelTracker) return;
  firstValueTracked = true;
  window.funnelTracker.track('first_value', { platform, surface: 'painel_divulgacoes' });
}

// ── Init ───────────────────────────────────────────────────────────────────
(function init() {
  document.getElementById('product-url-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') analyzeProduct();
  });
})();

// ── Analyze product ────────────────────────────────────────────────────────
async function analyzeProduct() {
  const url = document.getElementById('product-url-input').value.trim();
  if (!url) {
    showError('Cole o link do produto primeiro.');
    return;
  }

  const btn = document.getElementById('btn-analyze');
  btn.disabled = true;
  btn.textContent = 'Analisando...';

  hideError();
  setLoading(true, 'Analisando produto...');
  hideResult();
  hideEmpty();

  try {
    const resp = await fetch('/api/divulgacoes/extract', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': getCsrfToken(),
      },
      credentials: 'include',
      body: JSON.stringify({ url }),
    });

    const data = await resp.json();

    if (!resp.ok || !data.success) {
      throw new Error(data.error || 'Erro ao analisar produto');
    }

    currentData = data;
    currentPlatform = data.platform || null;
    displayResult(data);
    showPublishSection(data);
    trackFirstValue(data.platform || null);

  } catch (err) {
    showError(err.message || 'Erro ao analisar. Verifique o link e tente novamente.');
    showEmpty();
  } finally {
    setLoading(false);
    btn.disabled = false;
    btn.textContent = '✨ Analisar';
  }
}

// ── Display result ─────────────────────────────────────────────────────────
function displayResult(data) {
  const { product, platform, affiliateLink, hasCredentials, credentialError } = data;

  // Platform badge
  const platformNames = {
    shopee: { name: 'SHOPEE', color: '#EE4D2D' },
    ml:     { name: 'MERCADO LIVRE', color: '#1259c3' },
    amazon: { name: 'AMAZON', color: '#FF9900' },
    magalu: { name: 'MAGALU', color: '#0086CC' },
  };
  const pc = platformNames[platform] || { name: platform.toUpperCase(), color: '#555' };
  const badge = document.getElementById('product-platform-badge');
  badge.textContent = pc.name;
  badge.style.background = pc.color;

  // Product image
  const wrap = document.getElementById('product-image-wrap');
  const placeholder = document.getElementById('img-placeholder');
  wrap.querySelectorAll('img').forEach(e => e.remove());

  if (product.imagem_url) {
    const img = document.createElement('img');
    img.src = `/api/proxy/img?url=${encodeURIComponent(product.imagem_url)}`;
    img.alt = product.titulo;
    img.onerror = () => { img.remove(); placeholder.style.display = ''; };
    placeholder.style.display = 'none';
    wrap.appendChild(img);
  } else {
    placeholder.style.display = '';
  }

  // Title
  document.getElementById('product-title').textContent = product.titulo || 'Produto sem título';

  // Price
  const priceOrig = document.getElementById('price-original');
  const priceCurr = document.getElementById('price-current');
  const priceDisc = document.getElementById('price-discount');

  if (product.preco) {
    priceCurr.textContent = 'R$ ' + product.preco;
  } else {
    priceCurr.textContent = 'Preço não disponível';
  }

  if (product.preco_original) {
    priceOrig.textContent = 'R$ ' + product.preco_original;
    priceOrig.style.display = '';

    const pCurr = parseFloat((product.preco || '0').replace(',', '.'));
    const pOrig = parseFloat(product.preco_original.replace(',', '.'));
    if (pOrig > pCurr && pCurr > 0) {
      const pct = Math.round((1 - pCurr / pOrig) * 100);
      if (pct > 0) {
        priceDisc.textContent = `-${pct}%`;
        priceDisc.style.display = '';
      } else {
        priceDisc.style.display = 'none';
      }
    } else {
      priceDisc.style.display = 'none';
    }
  } else {
    priceOrig.style.display = 'none';
    priceDisc.style.display = 'none';
  }

  // Affiliate link
  document.getElementById('affiliate-link-box').textContent = affiliateLink || 'Link não disponível';

  // Credential warning — mostra sempre que há erro, mesmo com credencial salva (ex: token expirado)
  const warn = document.getElementById('credential-warning');
  const configBtn = document.getElementById('btn-go-config');
  if (credentialError) {
    const isExpired = /expir|renovar|expirado/i.test(credentialError);
    warn.innerHTML = (isExpired ? '🔴 ' : '⚠️ ') + credentialError
      + (isExpired ? ' &nbsp;<strong>→ Atualize o token</strong>' : '');
    warn.className = 'credential-warning visible' + (isExpired ? ' expired' : '');
    configBtn.style.display = '';
  } else {
    warn.className = 'credential-warning';
    configBtn.style.display = 'none';
  }

  // Show result + draw initial preview
  document.getElementById('result-section').classList.add('visible');
  drawPreviewCard();
}

// ── Template selection ─────────────────────────────────────────────────────
function selectTemplate(btn, name) {
  document.querySelectorAll('.tpl-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentTemplate = name;
  const uploadArea = document.getElementById('custom-tpl-area');
  if (uploadArea) uploadArea.style.display = name === 'personalizado' ? '' : 'none';
  if (currentData) drawPreviewCard();
}

// ── Canvas drawing ─────────────────────────────────────────────────────────
const PLATFORM_COLORS = {
  shopee: { bg: '#EE4D2D', secondary: '#FF6B00', name: 'SHOPEE',        textColor: '#ffffff' },
  ml:     { bg: '#FFE600', secondary: '#1259c3', name: 'MERCADO LIVRE', textColor: '#212121' },
  amazon: { bg: '#FF9900', secondary: '#232F3E', name: 'AMAZON',        textColor: '#232F3E' },
  magalu: { bg: '#0086CC', secondary: '#E50000', name: 'MAGALU',        textColor: '#ffffff' },
};

async function drawPreviewCard() {
  if (!currentData) return;
  const canvas = document.getElementById('preview-canvas');
  await drawCardOnCanvas(canvas, 300, 300);
}

async function generateCard() {
  if (!currentData) return;
  const btn = document.getElementById('btn-generate');
  btn.disabled = true;
  btn.textContent = 'Gerando...';
  try {
    const exportCanvas = document.getElementById('export-canvas');
    await drawCardOnCanvas(exportCanvas, 1080, 1080);
    const previewCanvas = document.getElementById('preview-canvas');
    const pCtx = previewCanvas.getContext('2d');
    pCtx.clearRect(0, 0, 300, 300);
    pCtx.drawImage(exportCanvas, 0, 0, 300, 300);
    const dataUrl = exportCanvas.toDataURL('image/png');
    const dlBtn = document.getElementById('btn-download');
    dlBtn.href = dataUrl;
    const titleSlug = (currentData.product.titulo || 'produto').substring(0, 30).replace(/[^a-zA-Z0-9]/g, '-');
    dlBtn.download = `card-${titleSlug}.png`;
    dlBtn.classList.add('visible');
  } catch (err) {
    console.error('Erro ao gerar card:', err);
  } finally {
    btn.disabled = false;
    btn.textContent = '✨ Gerar Card';
  }
}

async function drawCardOnCanvas(canvas, W, H) {
  const ctx = canvas.getContext('2d');
  const { product, platform } = currentData;
  const pc = PLATFORM_COLORS[platform] || PLATFORM_COLORS.shopee;
  ctx.clearRect(0, 0, W, H);
  switch (currentTemplate) {
    case 'destaque':      await drawTemplateDestaque(ctx, W, H, product, pc);      break;
    case 'promo':         await drawTemplatePromo(ctx, W, H, product, pc);         break;
    case 'minimal':       await drawTemplateMinimal(ctx, W, H, product, pc);       break;
    case 'personalizado': await drawTemplatePersonalizado(ctx, W, H, product, pc); break;
    default:              await drawTemplatePadrao(ctx, W, H, product, pc);        break;
  }
}

// ── Template: Padrão ───────────────────────────────────────────────────────
async function drawTemplatePadrao(ctx, W, H, product, pc) {
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);
  const headerH = Math.round(H * 0.08);
  ctx.fillStyle = pc.bg;
  ctx.fillRect(0, 0, W, headerH);
  ctx.fillStyle = pc.textColor;
  ctx.font = `bold ${Math.round(headerH * 0.52)}px Arial, sans-serif`;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(pc.name, W / 2, headerH / 2);
  const imgPad = Math.round(H * 0.05);
  const imgSize = Math.round(W * 0.52);
  const imgX = (W - imgSize) / 2;
  const imgY = headerH + imgPad;
  await drawProductImageContain(ctx, product.imagem_url, imgX, imgY, imgSize, imgSize, W, '#fff');
  const pad = Math.round(W * 0.055);
  let curY = imgY + imgSize + Math.round(H * 0.032);
  ctx.textAlign = 'left'; ctx.textBaseline = 'top';
  const titleFontSize = Math.round(W * 0.038);
  ctx.font = `600 ${titleFontSize}px Arial, sans-serif`;
  ctx.fillStyle = '#212121';
  wrapText(ctx, product.titulo || '', W - pad * 2, 2).forEach(line => {
    ctx.fillText(line, pad, curY); curY += titleFontSize * 1.4;
  });
  curY += Math.round(H * 0.012);
  if (product.preco_original) { curY = drawStrikePrice(ctx, product.preco_original, pad, curY, Math.round(W * 0.03), '#aaa'); }
  if (product.preco) { drawPrice(ctx, product, pad, curY, Math.round(W * 0.068), getPriceColor(pc), W); }
  drawWatermark(ctx, W, H, '#ccc');
}

// ── Template: Destaque ─────────────────────────────────────────────────────
async function drawTemplateDestaque(ctx, W, H, product, pc) {
  const splitH = Math.round(H * 0.50);
  ctx.fillStyle = pc.bg; ctx.fillRect(0, 0, W, splitH);
  ctx.fillStyle = '#ffffff'; ctx.fillRect(0, splitH, W, H - splitH);
  const ptFontSize = Math.round(W * 0.042);
  ctx.fillStyle = pc.textColor + 'BB';
  ctx.font = `800 ${ptFontSize}px Arial, sans-serif`;
  ctx.textAlign = 'left'; ctx.textBaseline = 'top';
  ctx.fillText(pc.name, Math.round(W * 0.06), Math.round(H * 0.038));
  const imgSize = Math.round(W * 0.46);
  const imgX = (W - imgSize) / 2;
  const imgY = Math.round(splitH - imgSize * 0.62);
  ctx.save();
  ctx.shadowColor = 'rgba(0,0,0,0.22)'; ctx.shadowBlur = Math.round(W * 0.025); ctx.shadowOffsetY = Math.round(W * 0.008);
  ctx.fillStyle = '#ffffff';
  const cardPad = Math.round(W * 0.018);
  roundedRect(ctx, imgX - cardPad, imgY - cardPad, imgSize + cardPad * 2, imgSize + cardPad * 2, Math.round(W * 0.02));
  ctx.fill(); ctx.restore();
  await drawProductImageContain(ctx, product.imagem_url, imgX, imgY, imgSize, imgSize, W, '#fff');
  const textTop = splitH + imgSize * 0.40 + Math.round(H * 0.025);
  const pad = Math.round(W * 0.06);
  let curY = textTop;
  const titleFontSize = Math.round(W * 0.036);
  ctx.font = `600 ${titleFontSize}px Arial, sans-serif`;
  ctx.fillStyle = '#444'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
  wrapText(ctx, product.titulo || '', W - pad * 2, 2).forEach(line => {
    ctx.fillText(line, W / 2, curY); curY += titleFontSize * 1.4;
  });
  curY += Math.round(H * 0.012);
  // Preço riscado centralizado (se houver desconto)
  if (product.preco_original) {
    const strikeSize = Math.round(W * 0.028);
    ctx.font = `${strikeSize}px Arial, sans-serif`;
    ctx.fillStyle = '#999';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    const strikeTxt = 'De R$ ' + product.preco_original;
    ctx.fillText(strikeTxt, W / 2, curY);
    const tw = ctx.measureText(strikeTxt).width;
    ctx.strokeStyle = '#999'; ctx.lineWidth = Math.max(1, strikeSize * 0.07);
    ctx.beginPath();
    ctx.moveTo(W / 2 - tw / 2, curY + strikeSize * 0.55);
    ctx.lineTo(W / 2 + tw / 2, curY + strikeSize * 0.55);
    ctx.stroke();
    curY += strikeSize * 1.7;
  }
  if (product.preco) {
    const priceFontSize = Math.round(W * 0.07);
    ctx.font = `bold ${priceFontSize}px Arial, sans-serif`;
    ctx.fillStyle = getPriceColor(pc); ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('R$ ' + product.preco, W / 2, curY);
    // Badge de desconto à direita do preço
    if (product.preco_original) {
      const priceW = ctx.measureText('R$ ' + product.preco).width;
      drawDiscountBadge(ctx, product, W / 2 - priceW / 2, curY, priceFontSize, W);
    }
  }
  drawWatermark(ctx, W, H, '#ccc');
}

// ── Template: Promo (dark) ─────────────────────────────────────────────────
async function drawTemplatePromo(ctx, W, H, product, pc) {
  ctx.fillStyle = '#111111'; ctx.fillRect(0, 0, W, H);
  const stripeW = Math.round(W * 0.035);
  ctx.fillStyle = pc.bg; ctx.fillRect(0, 0, stripeW, H);
  const ptFontSize = Math.round(W * 0.033);
  ctx.fillStyle = pc.bg; ctx.font = `bold ${ptFontSize}px Arial, sans-serif`;
  ctx.textAlign = 'right'; ctx.textBaseline = 'top';
  ctx.fillText(pc.name, W - Math.round(W * 0.04), Math.round(H * 0.032));
  const imgSize = Math.round(W * 0.48);
  const imgX = (W - imgSize) / 2;
  const imgY = Math.round(H * 0.1);
  ctx.save();
  ctx.shadowColor = pc.bg + '44'; ctx.shadowBlur = Math.round(W * 0.05);
  ctx.fillStyle = '#1e1e1e';
  roundedRect(ctx, imgX, imgY, imgSize, imgSize, Math.round(W * 0.02));
  ctx.fill(); ctx.restore();
  await drawProductImageContain(ctx, product.imagem_url, imgX, imgY, imgSize, imgSize, W, '#1e1e1e');
  const divY = imgY + imgSize + Math.round(H * 0.03);
  ctx.strokeStyle = pc.bg + '44'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(Math.round(W * 0.1), divY); ctx.lineTo(W - Math.round(W * 0.1), divY); ctx.stroke();
  const pad = Math.round(W * 0.07);
  let curY = divY + Math.round(H * 0.022);
  if (product.preco_original) { curY = drawStrikePrice(ctx, product.preco_original, pad, curY, Math.round(W * 0.03), '#555'); }
  if (product.preco) {
    const priceFontSize = Math.round(W * 0.075);
    ctx.font = `bold ${priceFontSize}px Arial, sans-serif`;
    ctx.fillStyle = pc.bg === '#FFE600' ? '#FFE600' : pc.bg;
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('R$ ' + product.preco, pad, curY);
    drawDiscountBadge(ctx, product, pad, curY, priceFontSize, W);
    curY += priceFontSize * 1.3;
  }
  const titleFontSize = Math.round(W * 0.033);
  ctx.font = `${titleFontSize}px Arial, sans-serif`;
  ctx.fillStyle = '#aaaaaa'; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
  wrapText(ctx, product.titulo || '', W - pad * 2 - stripeW, 2).forEach(line => {
    ctx.fillText(line, pad, curY); curY += titleFontSize * 1.4;
  });
  drawWatermark(ctx, W, H, '#444');
}

// ── Template: Minimal ─────────────────────────────────────────────────────
async function drawTemplateMinimal(ctx, W, H, product, pc) {
  const imgH = Math.round(H * 0.70);
  ctx.fillStyle = '#f5f5f5'; ctx.fillRect(0, 0, W, H);
  await drawProductImageCover(ctx, product.imagem_url, 0, 0, W, imgH, W);
  const gradStart = Math.round(imgH * 0.45);
  const grad = ctx.createLinearGradient(0, gradStart, 0, imgH);
  grad.addColorStop(0, 'rgba(0,0,0,0)'); grad.addColorStop(1, 'rgba(0,0,0,0.6)');
  ctx.fillStyle = grad; ctx.fillRect(0, gradStart, W, imgH - gradStart);
  const pad = Math.round(W * 0.055);
  const titleFontSize = Math.round(W * 0.042);
  ctx.font = `600 ${titleFontSize}px Arial, sans-serif`;
  ctx.fillStyle = '#ffffff'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
  const titleLines = wrapText(ctx, product.titulo || '', W - pad * 2, 2);
  let tY = imgH - Math.round(H * 0.02);
  [...titleLines].reverse().forEach(line => { ctx.fillText(line, pad, tY); tY -= titleFontSize * 1.3; });
  const stripY = imgH; const stripH = H - imgH;
  ctx.fillStyle = pc.bg; ctx.fillRect(0, stripY, W, stripH);
  if (product.preco) {
    const priceFontSize = Math.round(stripH * 0.40);
    ctx.font = `bold ${priceFontSize}px Arial, sans-serif`;
    ctx.fillStyle = pc.bg === '#FFE600' ? '#212121' : '#ffffff';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('R$ ' + product.preco, pad, stripY + stripH / 2);
  }
  ctx.fillStyle = (pc.bg === '#FFE600' ? 'rgba(0,0,0,0.25)' : 'rgba(255,255,255,0.35)');
  ctx.font = `bold ${Math.round(stripH * 0.22)}px Arial, sans-serif`;
  ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
  ctx.fillText(pc.name, W - pad, stripY + stripH / 2);
  ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.font = `${Math.round(W * 0.02)}px Arial, sans-serif`;
  ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
  ctx.fillText('⚡ multidown.app', W / 2, H - 5);
}

// ── Template: Personalizado ────────────────────────────────────────────────
async function drawTemplatePersonalizado(ctx, W, H, product, pc) {
  if (customTemplateImage) {
    ctx.drawImage(customTemplateImage, 0, 0, W, H);
  } else {
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, '#667eea'); grad.addColorStop(1, '#764ba2');
    ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.font = `bold ${Math.round(W * 0.038)}px Arial, sans-serif`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('Faça upload do seu template', W / 2, H / 2 - Math.round(H * 0.04));
    ctx.font = `${Math.round(W * 0.028)}px Arial, sans-serif`;
    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    ctx.fillText('(clique em "Escolher imagem")', W / 2, H / 2 + Math.round(H * 0.04));
    return;
  }
  const imgSize = Math.round(W * 0.34);
  const imgX = Math.round(W * 0.05);
  const imgY = H - imgSize - Math.round(H * 0.19);
  ctx.save();
  ctx.shadowColor = 'rgba(0,0,0,0.35)'; ctx.shadowBlur = Math.round(W * 0.02);
  ctx.fillStyle = '#ffffff';
  roundedRect(ctx, imgX - 4, imgY - 4, imgSize + 8, imgSize + 8, Math.round(W * 0.015));
  ctx.fill(); ctx.restore();
  await drawProductImageContain(ctx, product.imagem_url, imgX, imgY, imgSize, imgSize, W, '#fff');
  const stripH = Math.round(H * 0.17);
  const stripY = H - stripH;
  ctx.fillStyle = 'rgba(0,0,0,0.75)'; ctx.fillRect(0, stripY, W, stripH);
  const pad = Math.round(W * 0.06);
  const titleFontSize = Math.round(stripH * 0.22);
  ctx.font = `600 ${titleFontSize}px Arial, sans-serif`;
  ctx.fillStyle = '#ffffff'; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
  const tl = wrapText(ctx, product.titulo || '', W - pad * 2, 1);
  ctx.fillText(tl[0], pad, stripY + Math.round(stripH * 0.1));
  if (product.preco) {
    const priceFontSize = Math.round(stripH * 0.38);
    ctx.font = `bold ${priceFontSize}px Arial, sans-serif`;
    ctx.fillStyle = pc.bg === '#FFE600' ? '#FFE600' : (pc.bg === '#ffffff' ? '#fff' : pc.bg);
    ctx.textBaseline = 'bottom';
    ctx.fillText('R$ ' + product.preco, pad, H - Math.round(stripH * 0.1));
  }
}

// ── Custom template upload ─────────────────────────────────────────────────
function loadCustomTemplate(event) {
  const file = event.target.files[0];
  if (!file) return;
  const infoEl = document.getElementById('custom-tpl-info');
  const previewEl = document.getElementById('custom-tpl-preview');
  if (file.size > 8 * 1024 * 1024) {
    if (infoEl) infoEl.textContent = '⚠️ Imagem muito grande (máx 8MB)';
    return;
  }
  const reader = new FileReader();
  reader.onload = (e) => {
    const img = new Image();
    img.onload = () => {
      customTemplateImage = img;
      if (previewEl) { previewEl.src = e.target.result; previewEl.style.display = 'block'; }
      if (infoEl) infoEl.textContent = `✅ ${file.name} (${img.naturalWidth}×${img.naturalHeight}px)`;
      if (currentData) drawPreviewCard();
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

// ── Canvas helpers ─────────────────────────────────────────────────────────
function getPriceColor(pc) {
  return pc.bg === '#FFE600' ? '#1259c3' : pc.bg;
}

function drawWatermark(ctx, W, H, color) {
  ctx.font = `${Math.round(W * 0.022)}px Arial, sans-serif`;
  ctx.fillStyle = color || '#ccc';
  ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
  ctx.fillText('⚡ multidown.app', W / 2, H - Math.round(W * 0.016));
}

function drawStrikePrice(ctx, preco_original, x, y, fontSize, color) {
  ctx.font = `${fontSize}px Arial, sans-serif`;
  ctx.fillStyle = color;
  ctx.textAlign = 'left'; ctx.textBaseline = 'top';
  const txt = 'De R$ ' + preco_original;
  ctx.fillText(txt, x, y);
  const tw = ctx.measureText(txt).width;
  ctx.strokeStyle = color; ctx.lineWidth = Math.max(1, fontSize * 0.07);
  ctx.beginPath(); ctx.moveTo(x, y + fontSize * 0.55); ctx.lineTo(x + tw, y + fontSize * 0.55); ctx.stroke();
  return y + fontSize * 1.65;
}

function drawPrice(ctx, product, x, y, fontSize, color, W) {
  ctx.font = `bold ${fontSize}px Arial, sans-serif`;
  ctx.fillStyle = color;
  ctx.textAlign = 'left'; ctx.textBaseline = 'top';
  ctx.fillText('R$ ' + product.preco, x, y);
  drawDiscountBadge(ctx, product, x, y, fontSize, W);
}

function drawDiscountBadge(ctx, product, priceX, priceY, priceFontSize, W) {
  if (!product.preco_original || !product.preco) return;
  const pCurr = parseFloat((product.preco || '0').replace(',', '.'));
  const pOrig = parseFloat(product.preco_original.replace(',', '.'));
  if (!(pOrig > pCurr && pCurr > 0)) return;
  const pct = Math.round((1 - pCurr / pOrig) * 100);
  if (pct <= 0) return;
  ctx.save();
  ctx.font = `bold ${priceFontSize}px Arial, sans-serif`;
  const priceW = ctx.measureText('R$ ' + product.preco).width;
  const badgeX = priceX + priceW + Math.round(W * 0.02);
  const badgeH = Math.round(priceFontSize * 0.52);
  const badgeW = Math.round(W * 0.15);
  ctx.fillStyle = '#c62828';
  roundedRect(ctx, badgeX, priceY + (priceFontSize - badgeH) / 2, badgeW, badgeH, Math.round(badgeH * 0.28));
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold ${Math.round(badgeH * 0.62)}px Arial, sans-serif`;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(`-${pct}%`, badgeX + badgeW / 2, priceY + priceFontSize / 2);
  ctx.restore();
}

async function drawProductImageContain(ctx, imageUrl, x, y, w, h, W, bgColor) {
  ctx.fillStyle = bgColor || '#f8f8f8';
  roundedRect(ctx, x, y, w, h, Math.round(W * 0.015));
  ctx.fill();
  if (!imageUrl) { drawImagePlaceholder(ctx, x, y, w, h, W); return; }
  try {
    const img = await loadImage(`/api/proxy/img?url=${encodeURIComponent(imageUrl)}`);
    if (!img) { drawImagePlaceholder(ctx, x, y, w, h, W); return; }
    const scale = Math.min(w / img.naturalWidth, h / img.naturalHeight);
    const dw = img.naturalWidth * scale, dh = img.naturalHeight * scale;
    const dx = x + (w - dw) / 2, dy = y + (h - dh) / 2;
    ctx.save();
    roundedRect(ctx, x, y, w, h, Math.round(W * 0.015));
    ctx.clip();
    ctx.drawImage(img, dx, dy, dw, dh);
    ctx.restore();
  } catch { drawImagePlaceholder(ctx, x, y, w, h, W); }
}

async function drawProductImageCover(ctx, imageUrl, x, y, w, h, W) {
  ctx.fillStyle = '#e0e0e0'; ctx.fillRect(x, y, w, h);
  if (!imageUrl) { drawImagePlaceholder(ctx, x, y, w, h, W); return; }
  try {
    const img = await loadImage(`/api/proxy/img?url=${encodeURIComponent(imageUrl)}`);
    if (!img) { drawImagePlaceholder(ctx, x, y, w, h, W); return; }
    const scale = Math.max(w / img.naturalWidth, h / img.naturalHeight);
    const dw = img.naturalWidth * scale, dh = img.naturalHeight * scale;
    const dx = x + (w - dw) / 2, dy = y + (h - dh) / 2;
    ctx.save(); ctx.rect(x, y, w, h); ctx.clip();
    ctx.drawImage(img, dx, dy, dw, dh);
    ctx.restore();
  } catch { drawImagePlaceholder(ctx, x, y, w, h, W); }
}

function drawImagePlaceholder(ctx, x, y, w, h, W) {
  ctx.fillStyle = '#bbb'; ctx.font = `${Math.round(W * 0.08)}px Arial`;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('🖼️', x + w / 2, y + h / 2);
}

function loadImage(src) {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
    setTimeout(() => resolve(null), 8000);
  });
}

function wrapText(ctx, text, maxWidth, maxLines) {
  if (!text) return [''];
  const words = text.split(' ');
  const lines = [];
  let current = '';

  for (const word of words) {
    const test = current ? current + ' ' + word : word;
    if (ctx.measureText(test).width > maxWidth && current) {
      lines.push(current);
      current = word;
      if (lines.length >= maxLines) break;
    } else {
      current = test;
    }
  }

  if (current && lines.length < maxLines) {
    if (lines.length === maxLines - 1 && ctx.measureText(current).width > maxWidth) {
      // Truncate with ellipsis
      while (current.length > 0 && ctx.measureText(current + '…').width > maxWidth) {
        current = current.slice(0, -1);
      }
      lines.push(current + '…');
    } else {
      lines.push(current);
    }
  } else if (lines.length === maxLines && current) {
    // Ensure last line has ellipsis if there's more text
    let last = lines[maxLines - 1];
    while (last.length > 0 && ctx.measureText(last + '…').width > maxWidth) {
      last = last.slice(0, -1);
    }
    lines[maxLines - 1] = last + '…';
  }

  return lines.length ? lines : [''];
}

function roundedRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

// ── UI helpers ─────────────────────────────────────────────────────────────
function setLoading(show, text) {
  const el = document.getElementById('loading-state');
  if (show) {
    el.classList.add('visible');
    if (text) document.getElementById('loading-text').textContent = text;
  } else {
    el.classList.remove('visible');
  }
}

function hideResult() {
  document.getElementById('result-section').classList.remove('visible');
}

function showEmpty() {
  document.getElementById('empty-state').style.display = '';
}

function hideEmpty() {
  document.getElementById('empty-state').style.display = 'none';
}

function showError(msg) {
  const el = document.getElementById('analyze-error');
  el.textContent = msg;
  el.classList.add('visible');
}

function hideError() {
  document.getElementById('analyze-error').classList.remove('visible');
}

async function copyAffiliateLink() {
  const link = document.getElementById('affiliate-link-box').textContent;
  try {
    await navigator.clipboard.writeText(link);
    const btn = document.querySelector('.btn-copy-link');
    const orig = btn.textContent;
    btn.textContent = '✅ Copiado!';
    setTimeout(() => { btn.textContent = orig; }, 1800);
  } catch { alert('Copie o link manualmente: ' + link); }
}

function openAffiliateLink() {
  const link = document.getElementById('affiliate-link-box').textContent;
  if (link && link !== '—') window.open(link, '_blank');
}

// ── Publish Section ────────────────────────────────────────────────────────
let cachedGroups = null;

function showPublishSection(data) {
  const section = document.getElementById('publish-section');
  section.style.display = '';

  // Preencher mensagem padrão
  const { product, affiliateLink } = data;
  let msg = '';
  if (product.titulo) msg += `*${product.titulo}*\n`;
  if (product.preco_original) msg += `~De: R$ ${product.preco_original}~\n`;
  if (product.preco) {
    msg += `💰 *R$ ${product.preco}*`;
    if (product.preco_original) {
      const pOrig = parseFloat(product.preco_original.replace(',', '.'));
      const pAtual = parseFloat(product.preco.replace(',', '.'));
      if (pOrig > pAtual) {
        const disc = Math.round(((pOrig - pAtual) / pOrig) * 100);
        msg += ` (${disc}% OFF 🔥)`;
      }
    }
    msg += '\n';
  }
  if (affiliateLink) msg += `\n🛒 ${affiliateLink}`;
  document.getElementById('publish-caption').value = msg;

  // Reset feedback
  hideFeedback();

  // Carregar grupos
  loadGroups();
}

async function loadGroups() {
  const sel = document.getElementById('publish-group-select');

  // Limpar opções exceto Story
  while (sel.options.length > 1) sel.remove(1);

  if (cachedGroups) {
    populateGroupSelect(cachedGroups);
    return;
  }

  try {
    sel.disabled = true;
    const r = await fetch('/api/whatsapp/groups', { credentials: 'include' });
    const d = await r.json();
    cachedGroups = d.groups || [];
    populateGroupSelect(cachedGroups);
  } catch (e) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = '⚠️ WhatsApp não conectado';
    opt.disabled = true;
    sel.appendChild(opt);
  } finally {
    sel.disabled = false;
  }
}

function populateGroupSelect(groups) {
  const sel = document.getElementById('publish-group-select');
  if (!groups.length) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = '— Nenhum grupo encontrado —';
    opt.disabled = true;
    sel.appendChild(opt);
    return;
  }
  groups.forEach(g => {
    const opt = document.createElement('option');
    opt.value = g.id;
    opt.textContent = `👥 ${g.name}${g.participants ? ` (${g.participants})` : ''}`;
    sel.appendChild(opt);
  });
}

function onPublishWhenChange(radio) {
  const dtInput = document.getElementById('publish-datetime');
  if (radio.value === 'later') {
    dtInput.disabled = false;
    // Padrão: agora + 30 minutos
    if (!dtInput.value) {
      const d = new Date(Date.now() + 30 * 60 * 1000);
      d.setSeconds(0, 0);
      dtInput.value = d.toISOString().slice(0, 16);
    }
  } else {
    dtInput.disabled = true;
    dtInput.value = '';
  }
}

async function onPublish() {
  if (!currentData) return;

  const btn = document.getElementById('btn-publish');
  btn.disabled = true;
  btn.textContent = 'Enviando...';
  hideFeedback();

  try {
    // Gerar card canvas (1080×1080)
    await generateCard();
    const canvas = document.getElementById('export-canvas');
    const cardImageBase64 = canvas.toDataURL('image/png');

    const groupId = document.getElementById('publish-group-select').value;
    if (!groupId) throw new Error('Selecione um destino');

    const isLater = document.querySelector('input[name="publish-when"]:checked')?.value === 'later';
    const dtValue = document.getElementById('publish-datetime').value;
    const scheduledTime = isLater && dtValue ? new Date(dtValue).toISOString() : null;

    const body = {
      productUrl: currentData.originalUrl,
      affiliateLink: currentData.affiliateLink,
      platform: currentData.platform,
      caption: document.getElementById('publish-caption').value,
      groupId,
      scheduledTime,
      cardImageBase64,
    };

    const resp = await fetch('/api/divulgacoes/publish', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': getCsrfToken(),
      },
      credentials: 'include',
      body: JSON.stringify(body),
    });

    const data = await resp.json();
    if (!resp.ok || !data.success) throw new Error(data.error || 'Erro ao publicar');

    showFeedback(data.message || 'Publicado com sucesso!', 'success');
  } catch (err) {
    showFeedback(err.message || 'Erro ao publicar', 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = '📤 Publicar';
  }
}

function showFeedback(msg, type) {
  const el = document.getElementById('publish-feedback');
  el.textContent = msg;
  el.className = `publish-feedback ${type}`;
  el.style.display = '';
}

function hideFeedback() {
  const el = document.getElementById('publish-feedback');
  if (el) el.style.display = 'none';
}
