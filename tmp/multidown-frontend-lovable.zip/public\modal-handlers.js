// ============================================================================
// MODAL HANDLERS - WhatsApp e Agendamento
// ============================================================================

// Helper: Ler cookie por nome
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
  return null;
}

// Helper: Escape HTML para prevenir XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Helper: Toggle card de grupo (para Clone de Grupos)
function toggleGroupCard(cardElement, groupId, groupName) {
  const checkbox = cardElement.querySelector('input[type="checkbox"]');
  if (checkbox) {
    checkbox.checked = !checkbox.checked;
    cardElement.classList.toggle('selected', checkbox.checked);
  }
}

// ============================================================================
// MODAL WHATSAPP
// ============================================================================

var waStatusInterval = null;
var pausePollingUpdates = false;

// Abrir modal WhatsApp
function openWhatsAppModal() {
  const modal = document.getElementById('modal-whatsapp');
  if (modal) {
    modal.style.display = 'flex';

    // Verificar status imediatamente
    checkWhatsAppStatus();

    // Iniciar polling de status (a cada 2 segundos)
    waStatusInterval = setInterval(checkWhatsAppStatus, 2000);
  }
}

// Alternar entre abas de conexão
function switchTab(tabName) {
  // Remover active de todos os botões e conteúdos
  document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

  // Ativar aba selecionada
  document.querySelector(`[onclick="switchTab('${tabName}')"]`)?.classList.add('active');
  document.getElementById(`tab-${tabName}`)?.classList.add('active');

  // Pausar polling quando na aba de pareamento para não roubar o foco do input
  if (typeof pausePollingUpdates !== 'undefined') {
    pausePollingUpdates = (tabName === 'pairing');
  }
}

// Voltar para escolha de conexão
function backToConnectionChoice() {
  updateWhatsAppUI('disconnected');
}

// Fechar modal
function closeWhatsAppModal() {
  const modal = document.getElementById('modal-whatsapp');
  if (modal) {
    modal.style.display = 'none';
  }

  // Parar polling
  if (waStatusInterval) {
    clearInterval(waStatusInterval);
    waStatusInterval = null;
  }
}

// Verificar status do WhatsApp
async function checkWhatsAppStatus() {
  try {
    const response = await fetch('/api/whatsapp/status');
    const data = await response.json();

    if (data.success) {
      // Não sobrescrever UI quando usuário está interagindo com pairing mode
      if (!pausePollingUpdates || data.status === 'pairing' || data.status === 'connected') {
        pausePollingUpdates = false;
        updateWhatsAppUI(data.status, data.groupsCount);

        // Se tiver QR code disponível, buscar
        if (data.status === 'qr') {
          fetchQRCode();
        }

        // Se conectado, carregar grupos
        if (data.status === 'connected' && data.groupsCount > 0) {
          loadGroups();
        }
      }

      // Atualizar badge no botão (sempre)
      updateStatusBadge(data.status);
    }
  } catch (error) {
    console.error('Erro ao verificar status:', error);
  }
}

// Atualizar interface baseado no status
function updateWhatsAppUI(status, groupsCount) {
  // Esconder todos os cards
  const elements = {
    'wa-status-disconnected': 'none',
    'wa-status-connecting': 'none',
    'wa-status-qr': 'none',
    'wa-status-pairing': 'none',
    'wa-status-connected': 'none'
  };

  Object.keys(elements).forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });

  // Mostrar card apropriado
  let targetId = null;
  switch (status) {
    case 'disconnected':
      targetId = 'wa-status-disconnected';
      break;
    case 'connecting':
      targetId = 'wa-status-connecting';
      break;
    case 'qr':
      targetId = 'wa-status-qr';
      break;
    case 'pairing':
      targetId = 'wa-status-pairing';
      break;
    case 'connected':
      targetId = 'wa-status-connected';
      const countEl = document.getElementById('wa-groups-count');
      if (countEl) {
        countEl.textContent = `${groupsCount || 0} grupo(s) encontrado(s)`;
      }
      break;
  }

  if (targetId) {
    const el = document.getElementById(targetId);
    if (el) el.style.display = 'block';
  }
}

// Buscar QR Code (sem piscar — não esconde a imagem enquanto carrega)
async function fetchQRCode() {
  try {
    const response = await fetch('/api/whatsapp/qrcode');
    const data = await response.json();

    const img = document.getElementById('qr-image');
    const loader = document.getElementById('qr-loader');

    if (data.success && data.qrCode && img) {
      img.src = data.qrCode;
      img.style.display = 'block';
      if (loader) loader.style.display = 'none';
    }
  } catch (error) {
    console.error('Erro ao buscar QR code:', error);
  }
}

// Carregar grupos
async function loadGroups() {
  try {
    const response = await fetch('/api/whatsapp/groups');
    const data = await response.json();

    if (data.success && data.groups.length > 0) {
      displayGroups(data.groups);
      const list = document.getElementById('wa-groups-list');
      if (list) list.style.display = 'block';
    }
  } catch (error) {
    console.error('Erro ao carregar grupos:', error);
  }
}

// Exibir grupos
function displayGroups(groups) {
  const container = document.getElementById('groups-container');
  if (!container) return;

  container.innerHTML = groups.map(group => `
    <div class="group-item">
      <div>
        <div class="group-name">${group.name}</div>
        <div class="group-participants">${group.participants} participantes</div>
      </div>
      <div style="font-size: 12px; color: #999;">${group.id.substring(0, 15)}...</div>
    </div>
  `).join('');
}

// Atualizar badge de status
function updateStatusBadge(status) {
  const badge = document.getElementById('wa-status-badge');
  if (!badge) return;

  switch (status) {
    case 'connected':
      badge.textContent = 'ONLINE';
      badge.style.background = '#10b981';
      break;
    case 'qr':
    case 'pairing':
    case 'connecting':
      badge.textContent = 'CONECTANDO';
      badge.style.background = '#f59e0b';
      break;
    default:
      badge.textContent = 'OFFLINE';
      badge.style.background = '#6b7280';
  }
}

// Iniciar conexão WhatsApp
async function startWhatsAppConnection(type = 'qr') {
  try {
    const csrfToken = getCookie('csrf_token');

    if (type === 'pairing') {
      // Pairing Code - solicitar código
      const phoneInput = document.getElementById('pairing-phone-input');
      const phoneNumber = phoneInput ? phoneInput.value.trim() : '';

      if (!phoneNumber) {
        alert('Digite seu número de telefone com código do país (ex: +5511999999999)');
        return;
      }

      updateWhatsAppUI('connecting');

      const response = await fetch('/api/whatsapp/request-pairing-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken
        },
        body: JSON.stringify({ phoneNumber })
      });

      const data = await response.json();

      if (data.success && data.pairingCode) {
        // Mostrar código de pareamento
        displayPairingCode(data.pairingCode, phoneNumber);
      } else {
        alert('Erro ao gerar código: ' + (data.error || data.message));
        updateWhatsAppUI('disconnected');
      }
    } else {
      // QR Code - método tradicional
      const response = await fetch('/api/whatsapp/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken
        }
      });

      const data = await response.json();

      if (data.success) {
        updateWhatsAppUI('connecting');
        // Status será atualizado via polling
      } else {
        alert('Erro ao iniciar conexão: ' + (data.error || data.message));
      }
    }
  } catch (error) {
    console.error('Erro ao iniciar conexão:', error);
    alert('Erro ao iniciar conexão');
    updateWhatsAppUI('disconnected');
  }
}

// Exibir código de pareamento
function displayPairingCode(code, phoneNumber) {
  // Atualizar status para pairing
  updateWhatsAppUI('pairing');

  // Exibir número de telefone
  const phoneDisplay = document.getElementById('pairing-phone-display');
  if (phoneDisplay) {
    phoneDisplay.textContent = `Número: ${phoneNumber}`;
  }

  // Dividir código em dígitos (formato: XXXX-XXXX)
  const digits = code.split('');
  const digitElements = document.querySelectorAll('.code-digit');

  digitElements.forEach((el, index) => {
    if (index < 4) {
      el.textContent = digits[index] || '-';
    } else {
      el.textContent = digits[index] || '-';
    }
  });
}

// Trocar para modo pairing code (a partir da tela de QR)
function switchToPairingMode() {
  pausePollingUpdates = true;
  if (waStatusInterval) {
    clearInterval(waStatusInterval);
    waStatusInterval = null;
  }
  updateWhatsAppUI('disconnected');
  switchTab('pairing');
}

// Resetar conexão (gerar novo QR)
async function resetWhatsAppConnection() {
  if (!confirm('Isso irá gerar um novo QR Code. Continuar?')) return;

  try {
    const csrfToken = getCookie('csrf_token');

    const response = await fetch('/api/whatsapp/reset', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      }
    });

    const data = await response.json();

    if (data.success) {
      alert('Nova sessão iniciada! Escaneie o QR Code.');
      updateWhatsAppUI('qr');
    } else {
      alert('Erro ao resetar: ' + (data.error || data.message));
    }
  } catch (error) {
    console.error('Erro ao resetar:', error);
    alert('Erro ao resetar conexão');
  }
}

// Desconectar WhatsApp
async function disconnectWhatsApp() {
  if (!confirm('Deseja desconectar o WhatsApp?\n\nIsso apagará as credenciais e você precisará escanear um novo QR Code ou usar código de pareamento para reconectar.')) return;

  try {
    const csrfToken = getCookie('csrf_token');

    // Usar /reset em vez de /disconnect para limpar completamente as credenciais
    const response = await fetch('/api/whatsapp/reset', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      }
    });

    const data = await response.json();

    if (data.success) {
      alert('✅ WhatsApp desconectado!\n\nVocê pode conectar um novo número agora.');
      updateWhatsAppUI('disconnected');
    } else {
      alert('Erro ao desconectar: ' + (data.error || data.message));
    }
  } catch (error) {
    console.error('Erro ao desconectar:', error);
    alert('Erro ao desconectar');
  }
}

// Atualizar lista de grupos (força reload do WhatsApp)
async function refreshGroups() {
  const btn = document.querySelector('[onclick="refreshGroups()"]');
  const originalText = btn ? btn.textContent : '';
  if (btn) { btn.textContent = '⏳ Atualizando...'; btn.disabled = true; }

  try {
    const csrfToken = getCookie('csrf_token');
    const response = await fetch('/api/whatsapp/refresh-groups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
    });
    const data = await response.json();

    if (data.success && data.groups) {
      displayGroups(data.groups);
      const list = document.getElementById('wa-groups-list');
      if (list) list.style.display = 'block';
      const countEl = document.getElementById('wa-groups-count');
      if (countEl) countEl.textContent = `${data.count} grupo(s) encontrado(s)`;
      if (btn) btn.textContent = '✅ Atualizado!';
      setTimeout(() => { if (btn) { btn.textContent = originalText; btn.disabled = false; } }, 1500);
    } else {
      if (btn) { btn.textContent = originalText; btn.disabled = false; }
    }
  } catch (error) {
    console.error('Erro ao atualizar grupos:', error);
    if (btn) { btn.textContent = originalText; btn.disabled = false; }
  }
}

// ============================================================================
// MODAL AGENDAMENTO
// ============================================================================

// Abrir modal de agendamento
function openAgendarModal() {
  const modal = document.getElementById('modal-agendamento');
  if (modal) {
    modal.style.display = 'flex';

    // Definir horários padrão (daqui 10 minutos até +8 horas)
    const now = new Date();
    now.setMinutes(now.getMinutes() + 10);

    const startInput = document.getElementById('input-start-time');
    if (startInput) {
      startInput.value = now.toISOString().slice(0, 16);
    }

    const later = new Date(now.getTime() + 8 * 60 * 60 * 1000);
    const endInput = document.getElementById('input-end-time');
    if (endInput) {
      endInput.value = later.toISOString().slice(0, 16);
    }

    // Carregar grupos do WhatsApp
    loadWhatsAppGroupsForScheduler();
  }
}

// Fechar modal
function closeAgendarModal() {
  const modal = document.getElementById('modal-agendamento');
  if (modal) {
    modal.style.display = 'none';
  }
}

// Criar agendamento
async function createScheduling() {
  const urlsInput = document.getElementById('input-shopee-urls');
  const urlsText = urlsInput ? urlsInput.value : '';
  const shopeeUrls = urlsText.split('\n').filter(url => url.trim().length > 0);

  if (shopeeUrls.length === 0) {
    alert('❌ Adicione pelo menos um link da Shopee!');
    return;
  }

  const startInput = document.getElementById('input-start-time');
  const endInput = document.getElementById('input-end-time');
  const intervalInput = document.getElementById('input-interval');
  const groupInput = document.getElementById('input-destination-group');
  const captionInput = document.getElementById('input-caption');

  const startTime = startInput ? startInput.value : '';
  const endTime = endInput ? endInput.value : '';
  const intervalMinutes = intervalInput ? parseInt(intervalInput.value) : 0;
  const destinationGroup = groupInput ? groupInput.value.trim() : '';
  const caption = captionInput ? captionInput.value.trim() : '';

  if (!startTime || !endTime || !intervalMinutes || !destinationGroup) {
    alert('❌ Preencha todos os campos obrigatórios!');
    return;
  }

  // Aviso se horário de início está no passado
  const startDate = new Date(startTime);
  const now = new Date();
  if (startDate < now) {
    const confirmed = confirm(
      '⚠️ O horário de início está no passado!\n\n' +
      'Os posts com horário vencido serão enviados imediatamente na próxima rodada do worker (até 60s).\n\n' +
      'Deseja continuar mesmo assim?'
    );
    if (!confirmed) return;
  }

  try {
    const csrfToken = getCookie('csrf_token');

    const response = await fetch('/api/scheduling/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      },
      body: JSON.stringify({
        shopeeUrls,
        startTime: new Date(startTime).toISOString(),
        endTime: new Date(endTime).toISOString(),
        intervalMinutes,
        destinationGroup,
        caption
      })
    });

    const data = await response.json();

    if (data.success) {
      alert(`✅ ${data.message}\n\n📊 Total: ${data.count} post(s)\n🕐 Primeiro: ${new Date(data.firstPost).toLocaleString('pt-BR')}\n🕕 Último: ${new Date(data.lastPost).toLocaleString('pt-BR')}`);
      closeAgendarModal();

      // Limpar formulário
      if (urlsInput) urlsInput.value = '';
      if (groupInput) groupInput.value = '';
      if (captionInput) captionInput.value = '';

      // Recarregar página para atualizar estatísticas
      setTimeout(() => location.reload(), 1500);
    } else {
      alert('❌ Erro: ' + (data.error || data.message));
    }
  } catch (error) {
    console.error('Erro ao criar agendamento:', error);
    alert('❌ Erro ao criar agendamento. Verifique sua conexão.');
  }
}

// Carregar grupos do WhatsApp para o seletor
async function loadWhatsAppGroupsForScheduler() {
  const select = document.getElementById('input-destination-group');
  const status = document.getElementById('group-selector-status');

  if (!select) return;

  try {
    // Mostrar loading
    select.innerHTML = '<option value="">Carregando grupos...</option>';
    select.disabled = true;
    if (status) {
      status.textContent = 'Verificando conexão WhatsApp...';
      status.className = '';
    }

    // Verificar status da conexão
    const statusResponse = await fetch('/api/whatsapp/status');
    const statusData = await statusResponse.json();

    if (!statusData.success || statusData.status !== 'connected') {
      select.innerHTML = '<option value="">WhatsApp não conectado</option>';
      if (status) {
        status.textContent = 'Conecte o WhatsApp primeiro para ver os grupos';
        status.className = 'error';
      }
      return;
    }

    // Carregar grupos
    const groupsResponse = await fetch('/api/whatsapp/groups');
    const groupsData = await groupsResponse.json();

    if (!groupsData.success || !groupsData.groups || groupsData.groups.length === 0) {
      select.innerHTML = '<option value="">Nenhum grupo encontrado</option>';
      if (status) {
        status.textContent = 'Nenhum grupo do WhatsApp encontrado';
        status.className = 'error';
      }
      return;
    }

    // Popular dropdown com os grupos
    select.innerHTML = '<option value="">Selecione um grupo...</option>' +
      groupsData.groups.map(group =>
        `<option value="${group.id}">${group.name} (${group.participants} participantes)</option>`
      ).join('');

    select.disabled = false;
    if (status) {
      status.textContent = `${groupsData.groups.length} grupo(s) disponível(is)`;
      status.className = 'success';
    }

  } catch (error) {
    console.error('Erro ao carregar grupos:', error);
    select.innerHTML = '<option value="">Erro ao carregar grupos</option>';
    if (status) {
      status.textContent = 'Erro ao carregar grupos. Tente novamente.';
      status.className = 'error';
    }
  }
}

// Atualizar lista de grupos
function refreshGroupsInScheduler() {
  loadWhatsAppGroupsForScheduler();
}

// Alternar tabs do modal de agendamento
function switchAgendaTab(tabName) {
  // Esconder todas as tabs e atualizar ARIA
  document.querySelectorAll('#modal-agendamento .tab-content').forEach(tab => {
    tab.style.display = 'none';
  });
  document.querySelectorAll('#modal-agendamento .tab-btn').forEach(btn => {
    btn.classList.remove('active');
    btn.setAttribute('aria-selected', 'false');
  });

  // Mostrar tab selecionada
  const tab = document.getElementById(`agenda-tab-${tabName}`);
  if (tab) tab.style.display = 'block';

  // Ativar botão e setar aria-selected
  const btn = document.getElementById(`tab-btn-${tabName}`);
  if (btn) {
    btn.classList.add('active');
    btn.setAttribute('aria-selected', 'true');
  }

  if (tabName === 'lista' && typeof loadSchedulesList === 'function') {
    loadSchedulesList();
  }
}

// Download do template Excel
async function downloadExcelTemplate() {
  try {
    const response = await fetch('/api/scheduling/template');

    if (!response.ok) {
      throw new Error('Erro ao baixar template');
    }

    // Criar blob e fazer download
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'template-agendamento.xlsx';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);

    alert('✅ Template baixado com sucesso! Preencha e faça upload.');
  } catch (error) {
    console.error('Erro ao baixar template:', error);
    alert('❌ Erro ao baixar template');
  }
}

// Upload de planilha Excel
async function handleExcelUpload(event) {
  const file = event.target.files[0];
  if (!file) return;

  const statusDiv = document.getElementById('excel-upload-status');
  const resultDiv = document.getElementById('excel-upload-result');

  // Mostrar loading
  if (statusDiv) {
    statusDiv.style.display = 'block';
    statusDiv.innerHTML = `
      <div style="text-align: center; padding: 20px;">
        <div class="spinner"></div>
        <p style="margin-top: 10px; color: #666;">Processando planilha...</p>
      </div>
    `;
  }

  if (resultDiv) resultDiv.style.display = 'none';

  try {
    const formData = new FormData();
    formData.append('file', file);

    const csrfToken = getCookie('csrf_token');
    const response = await fetch('/api/scheduling/upload-excel', {
      method: 'POST',
      headers: {
        'X-CSRF-Token': csrfToken
      },
      body: formData
    });

    const data = await response.json();

    if (statusDiv) statusDiv.style.display = 'none';

    if (data.success) {
      // Sucesso
      if (resultDiv) {
        resultDiv.style.display = 'block';
        resultDiv.innerHTML = `
          <div style="background: #e8f5e9; border-left: 4px solid #4caf50; padding: 16px; border-radius: 8px;">
            <h4 style="margin: 0 0 10px 0; color: #2e7d32;">✅ ${data.message}</h4>
            <div style="color: #666; font-size: 14px;">
              <p style="margin: 5px 0;">📊 Total processado: ${data.totalFound} linha(s)</p>
              <p style="margin: 5px 0;">✅ Agendados: ${data.validCount}</p>
              ${data.errorCount > 0 ? `<p style="margin: 5px 0; color: #d32f2f;">❌ Erros: ${data.errorCount}</p>` : ''}
              ${data.meta.minDate ? `<p style="margin: 5px 0;">🕐 Primeiro post: ${new Date(data.meta.minDate).toLocaleString('pt-BR')}</p>` : ''}
              ${data.meta.maxDate ? `<p style="margin: 5px 0;">🕕 Último post: ${new Date(data.meta.maxDate).toLocaleString('pt-BR')}</p>` : ''}
            </div>
            ${data.errors && data.errors.length > 0 ? `
              <details style="margin-top: 15px;">
                <summary style="cursor: pointer; color: #d32f2f; font-weight: 600;">Ver erros (${data.errors.length})</summary>
                <ul style="margin: 10px 0; padding-left: 20px; max-height: 200px; overflow-y: auto;">
                  ${data.errors.map(err => `<li style="margin: 5px 0; font-size: 13px;">${err.message}</li>`).join('')}
                </ul>
              </details>
            ` : ''}
            <button type="button" class="btn-primary" onclick="closeAgendarModal(); location.reload();" style="margin-top: 15px;">
              OK, Fechar
            </button>
          </div>
        `;
      }

      // Limpar input
      event.target.value = '';
    } else {
      // Erro
      if (resultDiv) {
        resultDiv.style.display = 'block';
        resultDiv.innerHTML = `
          <div style="background: #ffebee; border-left: 4px solid #d32f2f; padding: 16px; border-radius: 8px;">
            <h4 style="margin: 0 0 10px 0; color: #d32f2f;">❌ Erro ao processar planilha</h4>
            <p style="margin: 0; color: #666; font-size: 14px;">${data.message || data.error}</p>
          </div>
        `;
      }
    }
  } catch (error) {
    console.error('Erro no upload:', error);
    if (statusDiv) statusDiv.style.display = 'none';
    if (resultDiv) {
      resultDiv.style.display = 'block';
      resultDiv.innerHTML = `
        <div style="background: #ffebee; border-left: 4px solid #d32f2f; padding: 16px; border-radius: 8px;">
          <h4 style="margin: 0 0 10px 0; color: #d32f2f;">❌ Erro ao fazer upload</h4>
          <p style="margin: 0; color: #666; font-size: 14px;">Verifique sua conexão e tente novamente.</p>
        </div>
      `;
    }
  }
}

// ─── Aba "Meus Agendamentos" ──────────────────────────────────────────────────

let _scheduleFilter = 'all';

function filterSchedules(status, btn) {
  _scheduleFilter = status;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  loadSchedulesList();
}

async function loadSchedulesList() {
  const container = document.getElementById('schedules-list-container');
  if (!container) return;
  container.innerHTML = '<p style="text-align:center; color:#999;">Carregando...</p>';

  try {
    const qs = _scheduleFilter !== 'all' ? `?status=${_scheduleFilter}` : '';
    const res = await fetch(`/api/scheduling/list${qs}`);
    const data = await res.json();

    if (!data.success || data.schedules.length === 0) {
      container.innerHTML = '<p style="text-align:center; color:#aaa; margin-top:24px;">Nenhum agendamento encontrado.</p>';
      return;
    }

    // Índice do primeiro item pending (será destacado como "próximo")
    const firstPendingIdx = data.schedules.findIndex(s => s.status === 'pending');

    container.innerHTML = data.schedules.map((s, idx) => {
      const dt = new Date(s.scheduled_time).toLocaleString('pt-BR');
      const iso = new Date(new Date(s.scheduled_time).getTime()
        - new Date(s.scheduled_time).getTimezoneOffset() * 60000)
        .toISOString().slice(0, 16);
      const urlShort = s.shopee_url.length > 55 ? s.shopee_url.substring(0, 55) + '…' : s.shopee_url;
      const canEdit = s.status === 'pending' || s.status === 'failed';
      const editLabel = s.status === 'failed' ? '🔁 Reagendar' : '✏️ Editar horário';

      // Badge de status
      const isNext = s.status === 'pending' && idx === firstPendingIdx;
      let statusLabel, statusBadgeStyle;
      if (isNext) {
        statusLabel = '🔜 PRÓXIMO';
        statusBadgeStyle = 'background:linear-gradient(135deg,#FF6B35,#ff9a00);color:#fff;font-weight:700;font-size:11px;padding:3px 10px;border-radius:20px;letter-spacing:.5px;';
      } else {
        const labels = { pending: '⏳ Pendente', sent: '✅ Enviado', failed: '❌ Falhou' };
        statusLabel = labels[s.status] || s.status;
        statusBadgeStyle = '';
      }

      // Tempo relativo
      const diffMs = new Date(s.scheduled_time) - new Date();
      let relTime = '';
      if (s.status === 'pending') {
        if (diffMs <= 0) {
          relTime = '<span style="color:#FF6B35;font-weight:600;font-size:11px;">▶ Enviando em breve</span>';
        } else {
          const diffMin = Math.round(diffMs / 60000);
          const diffH = Math.floor(diffMin / 60);
          const diffM = diffMin % 60;
          const rel = diffH > 0 ? `em ${diffH}h${diffM > 0 ? diffM + 'min' : ''}` : `em ${diffMin}min`;
          relTime = `<span style="color:#888;font-size:11px;">${rel}</span>`;
        }
      }

      const actions = canEdit ? `
        <div class="s-actions" id="actions-${s.id}">
          <button class="s-btn-edit" onclick="editScheduleTime(${s.id})"
                  aria-label="${editLabel} agendamento #${s.id}">${editLabel}</button>
          <button class="s-btn-del" onclick="deleteSchedule(${s.id})"
                  aria-label="Excluir agendamento #${s.id}">🗑️ Excluir</button>
        </div>
        <div class="s-inline-edit" id="edit-form-${s.id}" style="display:none;" role="group" aria-label="Novo horário">
          <label for="edit-time-${s.id}" style="font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:4px;">Novo horário:</label>
          <input type="datetime-local" id="edit-time-${s.id}" value="${iso}"
                 style="width:100%;padding:8px;border:2px solid #FF6B35;border-radius:6px;font-size:13px;box-sizing:border-box;">
          <div style="display:flex;gap:8px;margin-top:8px;">
            <button class="s-btn-edit" onclick="confirmReschedule(${s.id})" style="flex:1;">✅ Confirmar</button>
            <button class="s-btn-del" onclick="cancelReschedule(${s.id})" style="flex:1;">✖ Cancelar</button>
          </div>
        </div>` : '';

      const nextBorderStyle = isNext
        ? 'border-left:4px solid #FF6B35; background:linear-gradient(135deg,#fff9f5,#fff);'
        : '';

      return `
        <div class="schedule-item ${s.status}" data-id="${s.id}" style="${nextBorderStyle}">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            ${statusBadgeStyle
              ? `<span style="${statusBadgeStyle}">${statusLabel}</span>`
              : `<span class="s-badge ${s.status}">${statusLabel}</span>`
            }
            <span style="font-size:11px; color:#999;">#${s.id}</span>
          </div>
          <div class="s-url" title="${s.shopee_url}">${urlShort}</div>
          <div class="s-meta" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
            <time datetime="${s.scheduled_time}">🕐 ${dt}</time>
            ${relTime}
            <span style="color:#ccc;">|</span>
            <span>📱 ${s.destination_group || '—'}</span>
          </div>
          ${actions}
        </div>`;
    }).join('');

  } catch (err) {
    container.innerHTML = '<p style="text-align:center; color:#f44336;" role="alert">Erro ao carregar agendamentos.</p>';
  }
}

function editScheduleTime(id) {
  document.getElementById(`actions-${id}`).style.display = 'none';
  const form = document.getElementById(`edit-form-${id}`);
  form.style.display = 'block';
  form.querySelector('input').focus();
}

function cancelReschedule(id) {
  document.getElementById(`edit-form-${id}`).style.display = 'none';
  document.getElementById(`actions-${id}`).style.display = 'flex';
}

async function confirmReschedule(id) {
  const input = document.getElementById(`edit-time-${id}`);
  const newTime = new Date(input.value);
  if (isNaN(newTime.getTime())) {
    showToast('Data/hora inválida!', 'error');
    return;
  }

  try {
    const csrfToken = getCookie('csrf_token');
    const res = await fetch(`/api/scheduling/${id}/reschedule`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
      body: JSON.stringify({ newTime: newTime.toISOString() })
    });
    const data = await res.json();
    if (data.success) {
      showToast('Horário atualizado com sucesso!', 'success');
      loadSchedulesList();
    } else {
      showToast(data.error || data.message, 'error');
    }
  } catch (err) {
    showToast('Erro ao editar agendamento.', 'error');
  }
}

async function deleteAllSchedules() {
  if (!confirm('Excluir TODOS os agendamentos pendentes e com falha? Esta ação não pode ser desfeita.')) return;

  try {
    const csrfToken = getCookie('csrf_token');
    const res = await fetch('/api/scheduling/all', {
      method: 'DELETE',
      headers: { 'X-CSRF-Token': csrfToken }
    });
    const data = await res.json();
    if (data.success) {
      showToast(`${data.count} agendamento(s) excluído(s)!`, 'success');
      loadSchedulesList();
    } else {
      showToast(data.error || data.message, 'error');
    }
  } catch (err) {
    showToast('Erro ao excluir agendamentos.', 'error');
  }
}

async function deleteSchedule(id) {
  if (!confirm(`Excluir agendamento #${id}? Esta ação não pode ser desfeita.`)) return;

  try {
    const csrfToken = getCookie('csrf_token');
    const res = await fetch(`/api/scheduling/${id}`, {
      method: 'DELETE',
      headers: { 'X-CSRF-Token': csrfToken }
    });
    const data = await res.json();
    if (data.success) {
      showToast('Agendamento excluído!', 'success');
      loadSchedulesList();
    } else {
      showToast(data.error || data.message, 'error');
    }
  } catch (err) {
    showToast('Erro ao excluir agendamento.', 'error');
  }
}

// ─── Toast Notification System ────────────────────────────────────────────────
function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.setAttribute('aria-live', 'polite');
    container.setAttribute('aria-atomic', 'false');
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.setAttribute('role', type === 'error' ? 'alert' : 'status');
  const icon = { success: '✅', error: '❌', info: 'ℹ️' }[type] || '';
  toast.textContent = `${icon} ${message}`;
  container.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add('toast-visible'));
  setTimeout(() => {
    toast.classList.remove('toast-visible');
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ============================================================================
// MODAL CONFIGURACOES
// ============================================================================

function openConfigModal() {
  const modal = document.getElementById('modal-configuracoes');
  if (modal) {
    modal.style.display = 'flex';
    loadConfig();
    switchConfigTab('shopee'); // Sempre abrir na aba Shopee
  }
}

function closeConfigModal() {
  const modal = document.getElementById('modal-configuracoes');
  if (modal) modal.style.display = 'none';
}

function switchConfigTab(tabName) {
  // Desativar todas as tabs e conteúdos
  document.querySelectorAll('.config-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.config-tab-content').forEach(c => c.classList.remove('active'));

  // Ativar tab e conteúdo selecionados
  const tabBtn = document.getElementById(`cfg-tab-${tabName}`);
  const tabContent = document.getElementById(`cfg-content-${tabName}`);
  if (tabBtn) tabBtn.classList.add('active');
  if (tabContent) tabContent.classList.add('active');
}

async function loadConfig() {
  try {
    const response = await fetch('/api/config');
    const data = await response.json();

    if (data.success && data.config) {
      const c = data.config;

      // Shopee
      const idEl = document.getElementById('input-shopee-app-id');
      const secEl = document.getElementById('input-shopee-app-secret');
      if (idEl) idEl.value = c.shopeeAppId || '';
      if (secEl) secEl.value = c.hasShopeeSecret ? '********' : '';

      // Templates
      const headerEl = document.getElementById('input-header');
      const couponEl = document.getElementById('input-coupon-link');
      const groupEl  = document.getElementById('input-group-link');
      if (headerEl) headerEl.value = c.header || '';
      if (couponEl) couponEl.value = c.couponLink || '';
      if (groupEl)  groupEl.value  = c.groupLink || '';

      // Mercado Livre
      const mlWordEl   = document.getElementById('input-ml-matt-word');
      const mlToolEl   = document.getElementById('input-ml-matt-tool');
      const mlSocialEl = document.getElementById('input-ml-social-username');
      const mlSsidEl   = document.getElementById('input-ml-cookie-ssid');
      if (mlWordEl)   mlWordEl.value   = c.mlMattWord       || '';
      if (mlToolEl)   mlToolEl.value   = c.mlMattTool       || '';
      if (mlSocialEl) mlSocialEl.value = c.mlSocialUsername || '';
      if (mlSsidEl) {
        mlSsidEl.placeholder = c.hasMLCookies
          ? '✓ Token configurado — cole novo para substituir'
          : 'Cole aqui o token gerado pela extensão';
      }

      // Amazon
      const amzEl = document.getElementById('input-amazon-associate-tag');
      if (amzEl) amzEl.value = c.amazonAssociateTag || '';

      // Magalu
      const mgIdEl   = document.getElementById('input-magalu-partner-id');
      const mgSlugEl = document.getElementById('input-magalu-partner-slug');
      if (mgIdEl)   mgIdEl.value   = c.magaluPartnerId  || '';
      if (mgSlugEl) mgSlugEl.value = c.magaluPartnerSlug || '';
    }
  } catch (error) {
    console.error('Erro ao carregar config:', error);
  }
}

async function saveConfig() {
  // Coletar campos de todas as abas
  const shopeeAppId     = document.getElementById('input-shopee-app-id')?.value.trim()       || '';
  const shopeeAppSecret = document.getElementById('input-shopee-app-secret')?.value.trim()   || '';
  const header          = document.getElementById('input-header')?.value.trim()              || '';
  const couponLink      = document.getElementById('input-coupon-link')?.value.trim()         || '';
  const groupLink       = document.getElementById('input-group-link')?.value.trim()          || '';
  const mlMattWord        = document.getElementById('input-ml-matt-word')?.value.trim()         || '';
  const mlMattTool        = document.getElementById('input-ml-matt-tool')?.value.trim()         || '';
  const mlSocialUsername  = document.getElementById('input-ml-social-username')?.value.trim()   || '';
  const mlCookieSsid    = document.getElementById('input-ml-cookie-ssid')?.value.trim()      || '';
  const mlCookieSession = document.getElementById('input-ml-cookie-session')?.value.trim()   || '';
  const mlCookieGal     = document.getElementById('input-ml-cookie-gal')?.value.trim()       || '';
  const amazonAssociateTag  = document.getElementById('input-amazon-associate-tag')?.value.trim()  || '';
  const magaluPartnerId     = document.getElementById('input-magalu-partner-id')?.value.trim()     || '';
  const magaluPartnerSlug   = document.getElementById('input-magalu-partner-slug')?.value.trim()   || '';

  // Pelo menos uma plataforma configurada (mlCookieSsid também conta como ML configurado)
  if (!shopeeAppId && !mlMattWord && !mlCookieSsid && !amazonAssociateTag && !magaluPartnerId) {
    alert('Configure pelo menos uma plataforma de afiliado (Shopee, Mercado Livre, Amazon ou Magalu)!');
    return;
  }

  try {
    const csrfToken = getCookie('csrf_token');
    const response = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
      body: JSON.stringify({
        shopeeAppId, shopeeAppSecret, header, couponLink, groupLink,
        mlMattWord, mlMattTool, mlSocialUsername, mlCookieSsid, mlCookieSession, mlCookieGal,
        amazonAssociateTag,
        magaluPartnerId, magaluPartnerSlug
      })
    });

    const data = await response.json();
    if (data.success) {
      showToast('✅ Configurações salvas com sucesso!', 'success');
      closeConfigModal();
    } else {
      alert('❌ Erro: ' + (data.error || data.message));
    }
  } catch (error) {
    alert('❌ Erro ao salvar configurações');
    console.error(error);
  }
}

// ============================================================================
// MODAL CLONE DE GRUPOS
// ============================================================================

function openCloneGrupoModal() {
  const modal = document.getElementById('modal-clone-grupo');
  if (modal) {
    modal.style.display = 'flex';
    switchCloneTab('list');
    loadCloneConfigs();
  }
}

function closeCloneGrupoModal() {
  const modal = document.getElementById('modal-clone-grupo');
  if (modal) modal.style.display = 'none';
}

function switchCloneTab(tabName) {
  console.log('[Clone] switchCloneTab chamada com:', tabName);
  const modal = document.getElementById('modal-clone-grupo');
  if (!modal) {
    console.error('[Clone] Modal clone-grupo não encontrado!');
    return;
  }

  // Atualizar tabs apenas dentro do modal de clone
  modal.querySelectorAll('.clone-tab').forEach(btn => btn.classList.remove('active'));
  modal.querySelectorAll('.tab-content').forEach(content => {
    content.classList.remove('active');
    // Forçar esconder via inline style (sobrescreve CSS)
    content.style.display = 'none';
    content.style.opacity = '0';
  });

  // Ativar tab selecionada
  const tabContent = document.getElementById(`clone-tab-${tabName}`);
  if (tabContent) {
    console.log('[Clone] Ativando tab:', `clone-tab-${tabName}`);
    tabContent.classList.add('active');

    // Forçar mostrar via inline style (sobrescreve CSS)
    tabContent.style.display = 'block';
    tabContent.style.opacity = '1';

    console.log('[Clone] Tab ativada com display e opacity forçados via inline style');

    // Encontrar e ativar botão correspondente dentro do modal
    const tabBtns = modal.querySelectorAll('.clone-tab');
    if (tabName === 'list' && tabBtns[0]) tabBtns[0].classList.add('active');
    if (tabName === 'new' && tabBtns[1]) tabBtns[1].classList.add('active');
  } else {
    console.error('[Clone] Elemento não encontrado:', `clone-tab-${tabName}`);
  }

  // Se mudou para "new", carregar grupos
  if (tabName === 'new') {
    loadGroupsForClone();
  }
}

async function loadCloneConfigs() {
  const loading = document.getElementById('clone-list-loading');
  const empty = document.getElementById('clone-list-empty');
  const items = document.getElementById('clone-list-items');

  if (loading) loading.style.display = 'block';
  if (empty) empty.style.display = 'none';
  if (items) items.style.display = 'none';

  try {
    console.log('[Clone] Carregando configurações...');
    const response = await fetch('/api/group-clones', {
      credentials: 'include' // Garantir que cookies sejam enviados
    });

    console.log('[Clone] Response status:', response.status, response.statusText);

    // Verificar se a resposta foi bem-sucedida
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('[Clone] Erro na API:', response.status, errorData);

      if (response.status === 401) {
        alert('Sua sessão expirou. Por favor, faça login novamente.');
        window.location.href = '/login';
        return;
      }

      throw new Error(errorData.message || `Erro ${response.status}`);
    }

    const data = await response.json();
    console.log('[Clone] Dados recebidos:', JSON.stringify(data, null, 2));

    if (loading) loading.style.display = 'none';

    if (data.success && data.clones && data.clones.length > 0) {
      // Renderizar lista
      console.log('[Clone] Encontrado', data.clones.length, 'configurações, renderizando...');
      renderCloneList(data.clones);
      if (items) {
        items.style.display = 'block';
        console.log('[Clone] Container items exibido (display: block)');
      }
    } else {
      // Mostrar mensagem de vazio
      console.log('[Clone] Nenhuma configuração encontrada, mostrando empty state');
      if (empty) empty.style.display = 'block';
    }
  } catch (error) {
    console.error('[Clone] Erro ao carregar configurações:', error);
    if (loading) loading.style.display = 'none';
    if (empty) empty.style.display = 'block';

    // Mostrar erro ao usuário
    const emptyEl = document.getElementById('clone-list-empty');
    if (emptyEl) {
      emptyEl.innerHTML = `
        <p style="font-size: 48px; margin: 0;">⚠️</p>
        <p style="margin: 10px 0 0 0; color: #666;">Erro ao carregar configurações</p>
        <p style="margin: 5px 0; color: #999; font-size: 14px;">${error.message}</p>
      `;
      emptyEl.style.display = 'block';
    }
  }
}

function renderCloneList(clones) {
  console.log('[Clone] renderCloneList chamada com', clones.length, 'itens');
  const container = document.getElementById('clone-list-items');
  if (!container) {
    console.error('[Clone] Container clone-list-items não encontrado!');
    return;
  }

  console.log('[Clone] Renderizando lista no container...');
  container.innerHTML = clones.map(clone => {
    const destGroups = Array.isArray(clone.destinationGroups) ? clone.destinationGroups : [];
    const destNames = clone.destinationNames || {};

    return `
      <div class="clone-item">
        <div class="clone-item-header">
          <div class="clone-item-title">
            📱 ${clone.sourceGroupName || clone.sourceGroup}
          </div>
          <span class="clone-item-status ${clone.isActive ? 'active' : 'inactive'}">
            ${clone.isActive ? '✅ Ativo' : '⏸️ Pausado'}
          </span>
        </div>
        <div class="clone-item-details">
          <small>Criado em: ${new Date(clone.createdAt).toLocaleString('pt-BR')}</small>
        </div>
        <div class="clone-item-destinations">
          <strong>🎯 Grupos de Destino (${destGroups.length}):</strong>
          <ul>
            ${destGroups.map(gid => `<li>${destNames[gid] || gid}</li>`).join('')}
          </ul>
        </div>
        <div class="clone-item-actions">
          <button class="clone-btn-toggle" onclick="toggleCloneConfig(${clone.id})">
            ${clone.isActive ? '⏸️ Pausar' : '▶️ Ativar'}
          </button>
          <button class="clone-btn-delete" onclick="deleteCloneConfig(${clone.id})">
            🗑️ Deletar
          </button>
        </div>
      </div>
    `;
  }).join('');

  console.log('[Clone] Lista renderizada! innerHTML length:', container.innerHTML.length);
  console.log('[Clone] Container display:', window.getComputedStyle(container).display);
}

async function loadGroupsForClone() {
  const sourceSelect = document.getElementById('clone-source-group');
  const destContainer = document.getElementById('clone-dest-groups-container');

  if (!sourceSelect || !destContainer) return;

  try {
    console.log('[Clone] Carregando grupos WhatsApp...');
    const response = await fetch('/api/whatsapp/groups', {
      credentials: 'include'
    });

    console.log('[Clone] Response status:', response.status);

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('[Clone] Erro ao carregar grupos:', response.status, errorData);

      if (response.status === 401) {
        alert('Sua sessão expirou. Por favor, faça login novamente.');
        window.location.href = '/login';
        return;
      }

      throw new Error(errorData.message || `Erro ${response.status}`);
    }

    const data = await response.json();
    console.log('[Clone] Grupos recebidos:', JSON.stringify(data, null, 2));

    if (data.success && data.groups && data.groups.length > 0) {
      // Preencher select de origem
      sourceSelect.innerHTML = '<option value="">Selecione o grupo para monitorar</option>' +
        data.groups.map(g => `<option value="${g.id}">${g.name} (${g.participants} participantes)</option>`).join('');

      // Preencher cards de destino (design Shopee)
      destContainer.innerHTML = data.groups.map(g => `
        <div class="group-card" onclick="toggleGroupCard(this, '${g.id}', '${escapeHtml(g.name)}')">
          <input type="checkbox" id="dest-${g.id}" value="${g.id}" data-name="${escapeHtml(g.name)}">
          <div class="custom-checkbox">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="group-card-content">
            <h4 class="group-card-name">${escapeHtml(g.name)}</h4>
            <div class="group-card-meta">
              <svg viewBox="0 0 24 24" fill="none">
                <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M23 21v-2a4 4 0 00-3-3.87m-4-12a4 4 0 010 7.75M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              <span class="participant-badge">${g.participants} participantes</span>
            </div>
          </div>
        </div>
      `).join('');
    } else {
      sourceSelect.innerHTML = '<option value="">Nenhum grupo disponível</option>';
      destContainer.innerHTML = '<div style="text-align: center; color: #999; padding: 20px;">Nenhum grupo disponível. Conecte o WhatsApp primeiro.</div>';
    }
  } catch (error) {
    console.error('[Clone] Erro ao carregar grupos:', error);
    destContainer.innerHTML = `<div style="text-align: center; color: #c62828; padding: 20px;">Erro ao carregar grupos: ${error.message}</div>`;
  }
}

async function createCloneConfig() {
  const sourceSelect = document.getElementById('clone-source-group');
  const sourceGroup = sourceSelect?.value;
  const sourceGroupName = sourceSelect?.options[sourceSelect.selectedIndex]?.text;

  if (!sourceGroup) {
    alert('Selecione o grupo de origem!');
    return;
  }

  // Coletar grupos destino selecionados
  const destCheckboxes = document.querySelectorAll('#clone-dest-groups-container input[type="checkbox"]:checked');
  if (destCheckboxes.length === 0) {
    alert('Selecione pelo menos um grupo de destino!');
    return;
  }

  const destinationGroups = [];
  const destinationNames = {};

  destCheckboxes.forEach(cb => {
    destinationGroups.push(cb.value);
    destinationNames[cb.value] = cb.dataset.name;
  });

  try {
    const csrfToken = getCookie('csrf_token');
    const response = await fetch('/api/group-clones', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      },
      body: JSON.stringify({
        sourceGroup,
        sourceGroupName,
        destinationGroups,
        destinationNames,
        isActive: true
      })
    });

    const data = await response.json();

    if (data.success) {
      alert('✅ Configuração de clone criada com sucesso!');
      switchCloneTab('list');
      loadCloneConfigs();
    } else {
      alert('❌ ' + (data.message || data.error || 'Erro ao criar configuração'));
    }
  } catch (error) {
    console.error('Erro ao criar clone:', error);
    alert('❌ Erro ao criar configuração');
  }
}

async function toggleCloneConfig(cloneId) {
  if (!confirm('Deseja alterar o status desta configuração?')) return;

  try {
    const csrfToken = getCookie('csrf_token');
    const response = await fetch(`/api/group-clones/${cloneId}/toggle`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      }
    });

    const data = await response.json();

    if (data.success) {
      alert(`✅ Configuração ${data.isActive ? 'ativada' : 'pausada'} com sucesso!`);
      loadCloneConfigs();
    } else {
      alert('❌ Erro: ' + (data.error || data.message));
    }
  } catch (error) {
    console.error('Erro ao alternar status:', error);
    alert('❌ Erro ao alternar status');
  }
}

async function deleteCloneConfig(cloneId) {
  if (!confirm('⚠️ Tem certeza que deseja deletar esta configuração?\n\nEsta ação não pode ser desfeita.')) return;

  try {
    const csrfToken = getCookie('csrf_token');
    const response = await fetch(`/api/group-clones/${cloneId}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      }
    });

    const data = await response.json();

    if (data.success) {
      alert('✅ Configuração deletada com sucesso!');
      loadCloneConfigs();
    } else {
      alert('❌ Erro: ' + (data.error || data.message));
    }
  } catch (error) {
    console.error('Erro ao deletar:', error);
    alert('❌ Erro ao deletar configuração');
  }
}

// ============================================================================
// INICIALIZAÇÃO
// ============================================================================

// Inicializar event listeners quando o DOM estiver pronto
function initModalHandlers() {
  console.log('🔧 Inicializando handlers dos modais...');

  // Botão WhatsApp
  const btnWhatsApp = document.getElementById('btn-whatsapp-connect');
  if (btnWhatsApp) {
    btnWhatsApp.addEventListener('click', (e) => {
      e.preventDefault();
      openWhatsAppModal();
    });
    console.log('✅ Botão WhatsApp conectado');
  } else {
    console.warn('⚠️ Botão WhatsApp não encontrado');
  }

  // Botão Agendamento
  const btnAgendar = document.getElementById('btn-agendar-mensagem');
  if (btnAgendar) {
    btnAgendar.addEventListener('click', (e) => {
      e.preventDefault();
      openAgendarModal();
    });
    console.log('✅ Botão Agendamento conectado');
  } else {
    console.warn('⚠️ Botão Agendamento não encontrado');
  }

  // Botão Configurações
  const btnConfig = document.getElementById('btn-configuracoes');
  if (btnConfig) {
    btnConfig.addEventListener('click', (e) => {
      e.preventDefault();
      openConfigModal();
    });
    console.log('✅ Botão Configurações conectado');
  } else {
    console.warn('⚠️ Botão Configurações não encontrado');
  }

  // Botão Clone de Grupos
  const btnCloneGrupo = document.getElementById('btn-clone-grupo');
  if (btnCloneGrupo) {
    btnCloneGrupo.addEventListener('click', (e) => {
      e.preventDefault();
      openCloneGrupoModal();
    });
    console.log('✅ Botão Clone de Grupos conectado');
  } else {
    console.warn('⚠️ Botão Clone de Grupos não encontrado');
  }

  // Botão Buscar Produtos
  const btnBuscarProdutos = document.getElementById('btn-buscar-produtos');
  if (btnBuscarProdutos) {
    btnBuscarProdutos.addEventListener('click', (e) => {
      e.preventDefault();
      openBuscarProdutosModal();
    });
    console.log('✅ Botão Buscar Produtos conectado');
  } else {
    console.warn('⚠️ Botão Buscar Produtos não encontrado');
  }

  // Botão Automação Telegram
  const btnTelegramAuto = document.getElementById('btn-telegram-auto');
  if (btnTelegramAuto) {
    btnTelegramAuto.addEventListener('click', (e) => {
      e.preventDefault();
      openTelegramModal();
    });
    console.log('✅ Botão Telegram conectado');
  }

  // Botão Meu Site de Promoções
  const btnMeuSite = document.getElementById('btn-meu-site');
  if (btnMeuSite) {
    btnMeuSite.addEventListener('click', (e) => {
      e.preventDefault();
      openSitePromoModal();
    });
    console.log('✅ Botão Site de Promoções conectado');
  }

  // Fechar modais ao clicar fora
  const modalWA = document.getElementById('modal-whatsapp');
  if (modalWA) {
    modalWA.addEventListener('click', (e) => {
      if (e.target.id === 'modal-whatsapp') {
        closeWhatsAppModal();
      }
    });
  }

  const modalAgenda = document.getElementById('modal-agendamento');
  if (modalAgenda) {
    modalAgenda.addEventListener('click', (e) => {
      if (e.target.id === 'modal-agendamento') {
        closeAgendarModal();
      }
    });
  }

  const modalConfig = document.getElementById('modal-configuracoes');
  if (modalConfig) {
    modalConfig.addEventListener('click', (e) => {
      if (e.target.id === 'modal-configuracoes') {
        closeConfigModal();
      }
    });
  }

  const modalSitePromo = document.getElementById('modal-site-promocoes');
  if (modalSitePromo) {
    modalSitePromo.addEventListener('click', (e) => {
      if (e.target.id === 'modal-site-promocoes') {
        closeSitePromoModal();
      }
    });
  }

  const modalTelegram = document.getElementById('modal-telegram');
  if (modalTelegram) {
    modalTelegram.addEventListener('click', (e) => {
      if (e.target.id === 'modal-telegram') {
        closeTelegramModal();
      }
    });
  }

  // Verificar status WhatsApp ao carregar
  setTimeout(() => {
    checkWhatsAppStatus();
  }, 1000);

  console.log('✅ Handlers dos modais inicializados!');
}

// Auto-inicializar se document já estiver pronto
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initModalHandlers);
} else {
  initModalHandlers();
}

// ============================================================================
// EXPOR FUNÇÕES NO ESCOPO GLOBAL (para onclick inline funcionar)
// ============================================================================

// Funções WhatsApp
window.openWhatsAppModal = openWhatsAppModal;
window.closeWhatsAppModal = closeWhatsAppModal;
window.switchTab = switchTab;
window.backToConnectionChoice = backToConnectionChoice;
window.startWhatsAppConnection = startWhatsAppConnection;
window.resetWhatsAppConnection = resetWhatsAppConnection;
window.disconnectWhatsApp = disconnectWhatsApp;
window.refreshGroups = refreshGroups;

// Funções Agendamento
window.openAgendarModal = openAgendarModal;
window.closeAgendarModal = closeAgendarModal;
window.createScheduling = createScheduling;
window.refreshGroupsInScheduler = refreshGroupsInScheduler;
window.switchAgendaTab = switchAgendaTab;
window.downloadExcelTemplate = downloadExcelTemplate;
window.handleExcelUpload = handleExcelUpload;
window.loadSchedulesList = loadSchedulesList;
window.filterSchedules = filterSchedules;
window.editScheduleTime = editScheduleTime;
window.cancelReschedule = cancelReschedule;
window.confirmReschedule = confirmReschedule;
window.deleteSchedule = deleteSchedule;
window.showToast = showToast;

// ESC fecha modal de agendamento
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const modal = document.getElementById('modal-agendamento');
    if (modal && modal.style.display !== 'none') closeAgendarModal();
  }
});

// ============================================================================
// MODAL BUSCAR PRODUTOS SHOPEE
// ============================================================================

let produtosEncontrados = [];
let produtosSelecionados = new Set();
let gruposSelecionados = new Set();
let currentSearchKeyword = '';
let currentSearchPage = 1;
let searchHasNextPage = false;
let currentSearchPlatform = 'shopee'; // 'shopee' | 'ml'

function openBuscarProdutosModal() {
  console.log('[Search] Abrindo modal de busca de produtos');
  const modal = document.getElementById('modal-buscar-produtos');
  if (modal) {
    modal.style.display = 'flex';

    // Verificar se há produtos importados da extensão
    checkImportedProducts();
    modal.style.opacity = '1';
    loadGroupsForSearch();
    setDefaultSearchDates();
  }
}

function closeBuscarProdutosModal() {
  const modal = document.getElementById('modal-buscar-produtos');
  if (modal) {
    modal.style.display = 'none';
    modal.style.opacity = '0';
  }
  // Reset
  produtosEncontrados = [];
  produtosSelecionados = new Set();
  gruposSelecionados = new Set();
  currentSearchPlatform = 'shopee';
  document.getElementById('search-results').style.display = 'none';
}

function setDefaultSearchDates() {
  const hoje = new Date();
  // Formato YYYY-MM-DD em hora local (não UTC) para não avançar dia no fuso
  const pad = n => String(n).padStart(2, '0');
  const todayStr = `${hoje.getFullYear()}-${pad(hoje.getMonth() + 1)}-${pad(hoje.getDate())}`;

  document.getElementById('search-start-date').value = todayStr;
  document.getElementById('search-start-time').value = '10:00';
  const endTimeEl = document.getElementById('search-end-time');
  if (endTimeEl) endTimeEl.value = '21:00';
}

async function loadGroupsForSearch() {
  const container = document.getElementById('search-groups-container');
  if (!container) return;

  try {
    const response = await fetch('/api/whatsapp/groups', { credentials: 'include' });
    const data = await response.json();

    if (data.success && data.groups && data.groups.length > 0) {
      container.innerHTML = data.groups.map(g => `
        <div class="group-chip" onclick="toggleSearchGroup('${g.id}', this)">
          <input type="checkbox" id="search-group-${g.id}" value="${g.id}">
          ${g.name}
        </div>
      `).join('');
    } else {
      container.innerHTML = '<small style="color: #999;">Nenhum grupo disponível. Conecte o WhatsApp primeiro.</small>';
    }
  } catch (error) {
    console.error('[Search] Erro ao carregar grupos:', error);
    container.innerHTML = '<small style="color: #f44;">Erro ao carregar grupos</small>';
  }
}

function toggleSearchGroup(groupId, element) {
  if (gruposSelecionados.has(groupId)) {
    gruposSelecionados.delete(groupId);
    element.classList.remove('selected');
  } else {
    gruposSelecionados.add(groupId);
    element.classList.add('selected');
  }
}

function switchSearchPlatform(platform) {
  currentSearchPlatform = platform;

  // Atualizar título e subtítulo do modal
  const titleEl = document.querySelector('#modal-buscar-produtos .modal-title');
  const subtitleEl = document.querySelector('#modal-buscar-produtos .modal-subtitle');
  if (titleEl) titleEl.textContent = platform === 'ml' ? 'Buscar Produtos Mercado Livre' : 'Buscar Produtos Shopee';
  if (subtitleEl) subtitleEl.textContent = platform === 'ml'
    ? 'Encontre e agende ofertas do Mercado Livre automaticamente'
    : 'Encontre e agende produtos automaticamente';

  // Atualizar tabs
  document.querySelectorAll('.platform-tab').forEach(tab => {
    tab.classList.toggle('active', tab.dataset.platform === platform);
  });

  // Mostrar/esconder sort (apenas Shopee)
  const sortWrapper = document.getElementById('shopee-sort-wrapper');
  if (sortWrapper) sortWrapper.style.display = platform === 'shopee' ? 'flex' : 'none';

  // Mostrar/esconder atalhos de ofertas ML
  const mlOffersShortcuts = document.getElementById('ml-offers-shortcuts');
  if (mlOffersShortcuts) mlOffersShortcuts.style.display = platform === 'ml' ? 'block' : 'none';

  // Atualizar placeholder
  const input = document.getElementById('shopee-search-url');
  if (input) {
    input.placeholder = platform === 'ml'
      ? 'Ex: smartphone, ventilador, mochila...'
      : 'Ex: espelho, guarda-roupa, fone bluetooth...';
    input.value = '';
  }

  // Resetar resultados
  produtosEncontrados = [];
  produtosSelecionados = new Set();
  const results = document.getElementById('search-results');
  if (results) results.style.display = 'none';
  const status = document.getElementById('search-status');
  if (status) status.style.display = 'none';
}

async function buscarProdutos() {
  await buscarProdutosShopee();
}

async function buscarProdutosShopee() {
  const keyword = document.getElementById('shopee-search-url').value.trim();

  if (!keyword || keyword.length < 2) {
    alert('❌ Digite pelo menos 2 caracteres para buscar!');
    return;
  }

  currentSearchKeyword = keyword;
  currentSearchPage = 1;
  produtosEncontrados = [];
  produtosSelecionados = new Set();

  const loading = document.getElementById('search-loading');
  const results = document.getElementById('search-results');
  const status = document.getElementById('search-status');

  loading.style.display = 'block';
  results.style.display = 'none';
  status.style.display = 'none';

  try {
    await _fetchProdutos(keyword, 1, false);
    results.style.display = 'block';
  } catch (error) {
    console.error('[Search] Erro:', error);
    status.textContent = '❌ ' + error.message;
    status.className = 'status-message error';
    status.style.display = 'block';
  } finally {
    loading.style.display = 'none';
  }
}

async function carregarMLOfertas(promotionType, url) {
  currentSearchKeyword = `__ml_ofertas_${promotionType}`;
  currentSearchPage = 1;
  produtosEncontrados = [];
  produtosSelecionados = new Set();

  const loading = document.getElementById('search-loading');
  const results = document.getElementById('search-results');
  const status = document.getElementById('search-status');

  loading.style.display = 'block';
  results.style.display = 'none';
  if (status) status.style.display = 'none';

  const csrfToken = getCookie('csrf_token');

  try {
    const body = { promotionType, limit: 50 };
    if (url) body.url = url;

    const response = await fetch('/api/mercado-livre/offers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
      credentials: 'include',
      body: JSON.stringify(body)
    });

    const data = await response.json();
    if (!data.success) throw new Error(data.error || 'Erro ao carregar ofertas');

    produtosEncontrados = data.produtos;
    renderProdutos(data.produtos);
    results.style.display = 'block';

    const btnMais = document.getElementById('btn-carregar-mais');
    if (btnMais) btnMais.style.display = 'none';

    console.log(`[ML Ofertas] ${data.count} ofertas "${promotionType}" carregadas`);
  } catch (error) {
    console.error('[ML Ofertas] Erro:', error);
    if (status) {
      status.textContent = '❌ ' + error.message;
      status.className = 'status-message error';
      status.style.display = 'block';
    }
  } finally {
    loading.style.display = 'none';
  }
}

async function carregarMaisProdutos() {
  if (!searchHasNextPage) return;

  const btn = document.getElementById('btn-carregar-mais');
  btn.disabled = true;
  btn.textContent = 'Carregando...';

  try {
    currentSearchPage++;
    await _fetchProdutos(currentSearchKeyword, currentSearchPage, true);
  } catch (error) {
    console.error('[Search] Erro ao carregar mais:', error);
    currentSearchPage--;
  } finally {
    btn.disabled = false;
    btn.textContent = 'Carregar mais 50 produtos';
  }
}

async function _fetchProdutos(keyword, page, append) {
  const csrfToken = getCookie('csrf_token');
  console.log(`[Search] Buscando keyword="${keyword}" página=${page} plataforma=${currentSearchPlatform} append=${append}`);

  let response;
  if (currentSearchPlatform === 'ml') {
    response = await fetch('/api/mercado-livre/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
      credentials: 'include',
      body: JSON.stringify({ keyword, limit: 30 })
    });
  } else {
    const sortType = parseInt(document.getElementById('shopee-sort-type')?.value) || 2;
    response = await fetch('/api/shopee/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
      credentials: 'include',
      body: JSON.stringify({ keyword, page, sortType })
    });
  }

  const data = await response.json();
  if (!data.success) throw new Error(data.error || 'Erro ao buscar produtos');

  const offset = produtosEncontrados.length;
  produtosEncontrados = append ? [...produtosEncontrados, ...data.produtos] : data.produtos;

  if (append) {
    appendProdutos(data.produtos, offset);
  } else {
    renderProdutos(data.produtos);
  }

  searchHasNextPage = data.hasNextPage || false;
  const btnMais = document.getElementById('btn-carregar-mais');
  if (btnMais) btnMais.style.display = searchHasNextPage ? 'flex' : 'none';

  console.log(`[Search] Total acumulado: ${produtosEncontrados.length} | hasNextPage: ${searchHasNextPage}`);
}

function _buildProductCard(p, idx) {
  return `
    <div class="product-card" data-idx="${idx}" onclick="toggleProduto(${idx})">
      <div class="product-checkbox">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
          <path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
        </svg>
      </div>
      <img class="product-image" src="${p.imagem ? '/api/proxy/img?url=' + encodeURIComponent(p.imagem) : ''}" alt="${p.nome}" onerror="this.onerror=null;this.style.background='#f0f0f0'">
      <div class="product-info">
        <h4 class="product-name" title="${p.nome}">${p.nome}</h4>
        <div class="product-price">
          <span class="price-current">R$ ${p.precoAtual}</span>
          ${p.precoOriginal ? `<span class="price-original">R$ ${p.precoOriginal}</span>` : ''}
        </div>
        ${p.desconto ? `<span class="product-discount">${p.desconto}% OFF</span>` : ''}
      </div>
    </div>`;
}

function renderProdutos(produtos) {
  const grid = document.getElementById('products-grid');
  grid.innerHTML = produtos.map((p, idx) => _buildProductCard(p, idx)).join('');
  document.getElementById('selected-count').textContent = '0 selecionados';
}

function appendProdutos(produtos, offset) {
  const grid = document.getElementById('products-grid');
  grid.insertAdjacentHTML('beforeend', produtos.map((p, i) => _buildProductCard(p, offset + i)).join(''));
  document.getElementById('selected-count').textContent = produtosSelecionados.size + ' selecionados';
}

function toggleProduto(idx) {
  const cards = document.querySelectorAll('.product-card');
  const card = cards[idx];

  if (produtosSelecionados.has(idx)) {
    produtosSelecionados.delete(idx);
    card.classList.remove('selected');
  } else {
    produtosSelecionados.add(idx);
    card.classList.add('selected');
  }

  document.getElementById('selected-count').textContent = produtosSelecionados.size + ' selecionados';
}

function selecionarTodosProdutos() {
  const cards = document.querySelectorAll('.product-card');
  produtosSelecionados = new Set();

  cards.forEach((card, idx) => {
    produtosSelecionados.add(idx);
    card.classList.add('selected');
  });

  document.getElementById('selected-count').textContent = produtosSelecionados.size + ' selecionados';
}

function limparSelecaoProdutos() {
  const cards = document.querySelectorAll('.product-card');
  produtosSelecionados = new Set();

  cards.forEach(card => {
    card.classList.remove('selected');
  });

  document.getElementById('selected-count').textContent = '0 selecionados';
}

async function gerarExcelProdutos() {
  if (produtosSelecionados.size === 0) {
    alert('❌ Selecione pelo menos um produto!');
    return;
  }

  if (gruposSelecionados.size === 0) {
    alert('❌ Selecione pelo menos um grupo!');
    return;
  }

  const startDate = document.getElementById('search-start-date').value;
  const startTime = document.getElementById('search-start-time').value;
  const interval = parseInt(document.getElementById('search-interval').value);
  const captionTemplate = document.getElementById('search-caption-template').value.trim();

  if (!startDate || !startTime) {
    alert('❌ Preencha data e hora inicial!');
    return;
  }

  try {
    console.log('[Search] Gerando Excel...');
    const csrfToken = getCookie('csrf_token');

    const produtosSelecionadosArray = Array.from(produtosSelecionados).map(idx => produtosEncontrados[idx]);
    const gruposSelecionadosArray = Array.from(gruposSelecionados).map(id => ({ id }));

    const excelEndpoint = currentSearchPlatform === 'ml' ? '/api/mercado-livre/generate-excel' : '/api/shopee/generate-excel';
    const response = await fetch(excelEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      },
      credentials: 'include',
      body: JSON.stringify({
        produtos: produtosSelecionadosArray,
        grupos: gruposSelecionadosArray,
        startDate,
        startTime,
        interval,
        captionTemplate
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Erro ao gerar Excel');
    }

    // Download do arquivo
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `agendamento-shopee-${Date.now()}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);

    alert('✅ Excel gerado com sucesso!');
    console.log('[Search] Excel baixado');

  } catch (error) {
    console.error('[Search] Erro ao gerar Excel:', error);
    alert('❌ Erro ao gerar Excel: ' + error.message);
  }
}

async function agendarProdutosDireto() {
  if (produtosSelecionados.size === 0) {
    alert('❌ Selecione pelo menos um produto!');
    return;
  }

  if (gruposSelecionados.size === 0) {
    alert('❌ Selecione pelo menos um grupo!');
    return;
  }

  const startDate = document.getElementById('search-start-date').value;
  const startTime = document.getElementById('search-start-time').value;
  const endTime = document.getElementById('search-end-time')?.value || '';
  const interval = parseInt(document.getElementById('search-interval').value);
  const captionTemplate = document.getElementById('search-caption-template').value.trim();

  if (!startDate || !startTime) {
    alert('❌ Preencha data e hora inicial!');
    return;
  }

  const totalPosts = produtosSelecionados.size * gruposSelecionados.size;

  if (!confirm(`📅 Isso vai criar ${totalPosts} agendamentos.\n\nConfirmar?`)) {
    return;
  }

  try {
    console.log('[Search] Agendando produtos diretamente...');
    const csrfToken = getCookie('csrf_token');

    const produtosSelecionadosArray = Array.from(produtosSelecionados).map(idx => produtosEncontrados[idx]);
    const gruposSelecionadosArray = Array.from(gruposSelecionados).map(id => ({ id }));

    const scheduleEndpoint = currentSearchPlatform === 'ml' ? '/api/mercado-livre/schedule-batch' : '/api/shopee/schedule-batch';
    const response = await fetch(scheduleEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      },
      credentials: 'include',
      body: JSON.stringify({
        produtos: produtosSelecionadosArray,
        grupos: gruposSelecionadosArray,
        startDate,
        startTime,
        endTime,
        interval,
        captionTemplate
      })
    });

    const data = await response.json();

    if (data.success) {
      alert(`✅ ${data.count} posts agendados com sucesso!`);
      console.log('[Search] Agendamentos criados:', data.count);
      closeBuscarProdutosModal();
    } else {
      throw new Error(data.error || 'Erro ao agendar');
    }

  } catch (error) {
    console.error('[Search] Erro ao agendar:', error);
    alert('❌ Erro ao agendar: ' + error.message);
  }
}

// ============================================================================
// Verificar Produtos Importados da Extensão
// ============================================================================

async function checkImportedProducts() {
  try {
    console.log('[Search] Verificando produtos importados da extensão...');

    const response = await fetch('/api/shopee/imported-products');
    const data = await response.json();

    if (data.success && data.produtos && data.produtos.length > 0) {
      console.log('[Search] Encontrados', data.produtos.length, 'produtos da extensão');

      // Mostrar notificação visual
      const searchUrl = document.getElementById('shopee-search-url');
      if (searchUrl) {
        searchUrl.value = '✅ Produtos importados da extensão';
        searchUrl.disabled = true;
        searchUrl.style.background = '#e8f5e9';
        searchUrl.style.color = '#2e7d32';
        searchUrl.style.fontWeight = '600';
      }

      // Carregar produtos automaticamente
      produtosEncontrados = data.produtos;
      renderProdutos(data.produtos);

      // Exibir timestamp
      if (data.timestamp) {
        const time = new Date(data.timestamp).toLocaleString('pt-BR');
        console.log('[Search] Importados em:', time);
      }

      // Carregar grupos automaticamente
      await carregarGruposParaBusca();
    }

  } catch (error) {
    console.error('[Search] Erro ao verificar produtos importados:', error);
    // Silencioso - não é um erro crítico
  }
}

// Função auxiliar para carregar grupos na aba de busca
async function carregarGruposParaBusca() {
  try {
    const response = await fetch('/api/whatsapp/groups');
    const data = await response.json();

    if (data.success && data.groups) {
      const container = document.getElementById('search-groups-list');
      if (!container) return;

      container.innerHTML = '';

      if (data.groups.length === 0) {
        container.innerHTML = '<div style="text-align:center;padding:20px;color:#999;">Nenhum grupo disponível. Conecte o WhatsApp primeiro.</div>';
        return;
      }

      data.groups.forEach(group => {
        const card = document.createElement('div');
        card.className = 'search-group-card';
        card.innerHTML = `
          <input type="checkbox" id="search-group-${group.id}" onchange="toggleSearchGroup('${group.id}')">
          <label for="search-group-${group.id}">${group.subject}</label>
        `;
        container.appendChild(card);
      });
    }
  } catch (error) {
    console.error('[Search] Erro ao carregar grupos:', error);
  }
}

// Funções Configurações
window.openConfigModal = openConfigModal;
window.closeConfigModal = closeConfigModal;
window.saveConfig = saveConfig;
window.switchConfigTab = switchConfigTab;
window.loadConfig = loadConfig;

// Funções Clone de Grupos
window.openCloneGrupoModal = openCloneGrupoModal;
window.closeCloneGrupoModal = closeCloneGrupoModal;
window.switchCloneTab = switchCloneTab;
window.loadCloneConfigs = loadCloneConfigs;
window.loadGroupsForClone = loadGroupsForClone;
window.createCloneConfig = createCloneConfig;
window.toggleCloneConfig = toggleCloneConfig;
window.deleteCloneConfig = deleteCloneConfig;
window.toggleGroupCard = toggleGroupCard;

// Funções Buscar Produtos Shopee
window.openBuscarProdutosModal = openBuscarProdutosModal;
window.closeBuscarProdutosModal = closeBuscarProdutosModal;
window.buscarProdutosShopee = buscarProdutosShopee;
window.toggleProduto = toggleProduto;
window.selecionarTodosProdutos = selecionarTodosProdutos;
window.limparSelecaoProdutos = limparSelecaoProdutos;
window.toggleSearchGroup = toggleSearchGroup;
window.gerarExcelProdutos = gerarExcelProdutos;
window.agendarProdutosDireto = agendarProdutosDireto;
window.deleteAllSchedules = deleteAllSchedules;
window.carregarMaisProdutos = carregarMaisProdutos;

// ============================================================================
// MODAL TELEGRAM
// ============================================================================

let _tgChannels = [];
let _tgBotUsername = '@MultiDownBot';

function openTelegramModal() {
  const modal = document.getElementById('modal-telegram');
  if (modal) {
    modal.style.display = 'flex';
    _loadTelegramData();
  }
}

function closeTelegramModal() {
  const modal = document.getElementById('modal-telegram');
  if (modal) modal.style.display = 'none';
}

async function _loadTelegramData() {
  try {
    const botResp = await fetch('/api/config/telegram/bot-info', { credentials: 'include' });
    if (botResp.ok) {
      const botData = await botResp.json();
      _tgBotUsername = botData.username || '@MultiDownBot';
      const el = document.getElementById('tg-bot-username');
      if (el) el.textContent = _tgBotUsername;
    }

    const configResp = await fetch('/api/config', { credentials: 'include' });
    if (configResp.ok) {
      const configData = await configResp.json();
      _tgChannels = configData.config?.telegramChannels || [];
      _renderTelegramChannels();
    }
  } catch (e) {
    console.error('[Telegram Modal] Erro ao carregar dados:', e);
  }
}

function _renderTelegramChannels() {
  const list = document.getElementById('tg-channels-list');
  const section = document.getElementById('tg-channels-section');
  const emptyState = document.getElementById('tg-empty-state');

  if (!list || !section || !emptyState) return;

  if (!_tgChannels || _tgChannels.length === 0) {
    section.style.display = 'none';
    emptyState.style.display = 'block';
    return;
  }

  section.style.display = 'block';
  emptyState.style.display = 'none';

  list.innerHTML = _tgChannels.map(ch => `
    <div class="tg-channel-item ${ch.isActive ? 'active' : ''}">
      <div class="tg-channel-icon">📣</div>
      <div class="tg-channel-info">
        <div class="tg-channel-name">${escapeHtml(ch.name || ch.id)}</div>
        <div class="tg-channel-id">${escapeHtml(ch.id)}</div>
      </div>
      <label class="tg-toggle" title="${ch.isActive ? 'Desativar' : 'Ativar'}">
        <input type="checkbox" ${ch.isActive ? 'checked' : ''} onchange="toggleTelegramChannel('${escapeHtml(ch.id)}', this)">
        <span class="tg-toggle-slider"></span>
      </label>
      <button class="tg-btn-remove" onclick="removeTelegramChannel('${escapeHtml(ch.id)}')" title="Remover canal">🗑️</button>
    </div>
  `).join('');
}

function copyBotUsername() {
  navigator.clipboard.writeText(_tgBotUsername).then(() => {
    showToast('Username copiado! ' + _tgBotUsername, 'success');
  });
}

async function addTelegramChannel() {
  const input = document.getElementById('input-telegram-channel');
  const channelId = input?.value?.trim();

  if (!channelId) {
    _showTgStatus('Digite o @username ou ID do canal', 'error');
    return;
  }

  const addBtn = document.getElementById('tg-add-btn');
  const spinner = document.getElementById('tg-add-spinner');
  const btnText = document.getElementById('tg-add-text');

  if (addBtn) addBtn.disabled = true;
  if (spinner) spinner.style.display = 'inline';
  if (btnText) btnText.textContent = 'Verificando...';

  try {
    const csrfToken = getCookie('csrf_token');
    const resp = await fetch('/api/config/telegram/add', {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken,
      },
      body: JSON.stringify({ channelId }),
    });

    const data = await resp.json();

    if (resp.ok && data.success) {
      _showTgStatus('✅ ' + data.message, 'success');
      input.value = '';
      if (data.channel) {
        _tgChannels.push(data.channel);
        _renderTelegramChannels();
      }
    } else {
      _showTgStatus('❌ ' + (data.message || 'Erro ao adicionar canal'), 'error');
    }
  } catch (e) {
    _showTgStatus('❌ Erro de conexão. Tente novamente.', 'error');
  } finally {
    if (addBtn) addBtn.disabled = false;
    if (spinner) spinner.style.display = 'none';
    if (btnText) btnText.textContent = 'Verificar e Adicionar';
  }
}

async function toggleTelegramChannel(channelId, checkbox) {
  try {
    const csrfToken = getCookie('csrf_token');
    const resp = await fetch(`/api/config/telegram/${encodeURIComponent(channelId)}/toggle`, {
      method: 'PATCH',
      credentials: 'include',
      headers: { 'X-CSRF-Token': csrfToken, 'Content-Type': 'application/json' },
    });

    const data = await resp.json();
    if (resp.ok && data.success) {
      const ch = _tgChannels.find(c => c.id === channelId);
      if (ch) {
        ch.isActive = data.isActive;
        _renderTelegramChannels();
      }
    } else {
      checkbox.checked = !checkbox.checked;
      showToast('Erro ao alterar status do canal', 'error');
    }
  } catch {
    checkbox.checked = !checkbox.checked;
    showToast('Erro de conexão', 'error');
  }
}

async function removeTelegramChannel(channelId) {
  if (!confirm('Remover este canal?')) return;

  try {
    const csrfToken = getCookie('csrf_token');
    const resp = await fetch(`/api/config/telegram/${encodeURIComponent(channelId)}`, {
      method: 'DELETE',
      credentials: 'include',
      headers: { 'X-CSRF-Token': csrfToken },
    });

    const data = await resp.json();
    if (resp.ok && data.success) {
      _tgChannels = _tgChannels.filter(c => c.id !== channelId);
      _renderTelegramChannels();
      showToast('Canal removido com sucesso', 'success');
    } else {
      showToast('Erro ao remover canal', 'error');
    }
  } catch {
    showToast('Erro de conexão', 'error');
  }
}

function _showTgStatus(msg, type) {
  const el = document.getElementById('tg-add-status');
  if (!el) return;
  el.style.display = 'block';
  el.style.background = type === 'success' ? '#e8f5e9' : '#ffebee';
  el.style.color = type === 'success' ? '#2e7d32' : '#c62828';
  el.style.borderLeft = `4px solid ${type === 'success' ? '#2e7d32' : '#c62828'}`;
  el.textContent = msg;
}

// Expor funções Telegram
window.openTelegramModal = openTelegramModal;
window.closeTelegramModal = closeTelegramModal;
window.addTelegramChannel = addTelegramChannel;
window.toggleTelegramChannel = toggleTelegramChannel;
window.removeTelegramChannel = removeTelegramChannel;
window.copyBotUsername = copyBotUsername;

// ============================================================================
// MODAL SITE DE PROMOÇÕES
// ============================================================================

let _spCurrentSlug = '';
let _spSlugValid = false;

function openSitePromoModal() {
  const modal = document.getElementById('modal-site-promocoes');
  if (modal) {
    modal.style.display = 'flex';
    _loadSitePromoData();
  }
}

function closeSitePromoModal() {
  const modal = document.getElementById('modal-site-promocoes');
  if (modal) modal.style.display = 'none';
}

async function _loadSitePromoData() {
  try {
    const resp = await fetch('/api/promo/my-config', { credentials: 'include' });
    const data = await resp.json();
    if (!data.success) return;

    const config = data.config;
    if (!config) return;

    const enabledEl = document.getElementById('sp-enabled');
    const nameEl = document.getElementById('sp-name');
    const slugEl = document.getElementById('sp-slug');
    const bioEl = document.getElementById('sp-bio');
    const waEl = document.getElementById('sp-whatsapp');
    const tgEl = document.getElementById('sp-telegram-link');

    if (enabledEl) enabledEl.checked = config.enabled || false;
    if (nameEl) nameEl.value = config.name || '';
    if (slugEl) slugEl.value = config.slug || '';
    if (bioEl) bioEl.value = config.bio || '';
    if (waEl) waEl.value = config.whatsappLink || '';
    if (tgEl) tgEl.value = config.telegramLink || '';

    if (config.slug) {
      _spCurrentSlug = config.slug;
      _spSlugValid = true;
      _updateSlugStatus('ok', '✅ Slug salvo: /' + config.slug);
      _updateUrlPreview(config.slug);
    }
  } catch (e) {
    console.error('[SitePromo] Erro ao carregar config:', e);
  }
}

function onSlugInput(input) {
  const val = input.value.trim();
  const slugStatusEl = document.getElementById('slug-status');

  // Limpar status quando usuário digita
  if (slugStatusEl) {
    slugStatusEl.className = 'slug-status';
    slugStatusEl.textContent = '';
  }
  input.classList.remove('slug-ok', 'slug-error');
  _spSlugValid = (val === _spCurrentSlug); // válido se for o slug já salvo

  // Atualizar preview da URL em tempo real
  _updateUrlPreview(val);
}

async function checkSlugAvailability() {
  const slugEl = document.getElementById('sp-slug');
  const slug = slugEl?.value?.trim();

  if (!slug) {
    _updateSlugStatus('err', '⚠️ Digite um slug');
    return;
  }

  if (!/^[a-z0-9-]{3,50}$/.test(slug)) {
    _updateSlugStatus('err', '❌ Use apenas letras minúsculas, números e hífens (3-50 caracteres)');
    slugEl.classList.add('slug-error');
    return;
  }

  try {
    const resp = await fetch('/api/promo/check-slug/' + encodeURIComponent(slug), { credentials: 'include' });
    const data = await resp.json();

    if (data.available) {
      _updateSlugStatus('ok', '✅ Disponível!');
      slugEl.classList.remove('slug-error');
      slugEl.classList.add('slug-ok');
      _spSlugValid = true;
      _updateUrlPreview(slug);
    } else {
      _updateSlugStatus('err', '❌ ' + (data.reason || 'Slug indisponível'));
      slugEl.classList.add('slug-error');
      slugEl.classList.remove('slug-ok');
      _spSlugValid = false;
    }
  } catch (e) {
    _updateSlugStatus('err', '❌ Erro ao verificar. Tente novamente.');
  }
}

function _updateSlugStatus(type, msg) {
  const el = document.getElementById('slug-status');
  if (!el) return;
  el.className = 'slug-status ' + type;
  el.textContent = msg;
}

function _updateUrlPreview(slug) {
  const previewEl = document.getElementById('sp-url-preview');
  const urlTextEl = document.getElementById('sp-url-text');
  if (!previewEl || !urlTextEl) return;

  if (slug && slug.length >= 3) {
    const origin = window.location.origin;
    urlTextEl.textContent = origin + '/promo/' + slug;
    previewEl.classList.add('visible');
  } else {
    previewEl.classList.remove('visible');
  }
}

function copySitePromoUrl() {
  const urlTextEl = document.getElementById('sp-url-text');
  if (!urlTextEl) return;
  navigator.clipboard.writeText(urlTextEl.textContent).then(() => {
    showToast('Link copiado!', 'success');
  });
}

function viewSitePromo() {
  const urlTextEl = document.getElementById('sp-url-text');
  if (!urlTextEl) return;
  window.open(urlTextEl.textContent, '_blank', 'noopener');
}

async function saveSitePromoConfig() {
  const saveBtn = document.getElementById('sp-save-btn');
  const statusEl = document.getElementById('sp-status-msg');

  const slug = document.getElementById('sp-slug')?.value?.trim() || '';

  // Validar slug se fornecido
  if (slug && !/^[a-z0-9-]{3,50}$/.test(slug)) {
    _showSpStatus('❌ Slug inválido. Use apenas letras minúsculas, números e hífens (3-50 caracteres).', 'error');
    return;
  }

  if (slug && slug !== _spCurrentSlug && !_spSlugValid) {
    _showSpStatus('⚠️ Verifique a disponibilidade do slug antes de salvar.', 'error');
    return;
  }

  const payload = {
    enabled: document.getElementById('sp-enabled')?.checked || false,
    name: document.getElementById('sp-name')?.value?.trim() || '',
    slug,
    bio: document.getElementById('sp-bio')?.value?.trim() || '',
    whatsappLink: document.getElementById('sp-whatsapp')?.value?.trim() || '',
    telegramLink: document.getElementById('sp-telegram-link')?.value?.trim() || '',
  };

  if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Salvando...'; }
  _hideSpStatus();

  try {
    const csrfToken = getCookie('csrf_token');
    const resp = await fetch('/api/promo/my-config', {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken,
      },
      body: JSON.stringify(payload),
    });

    const data = await resp.json();

    if (resp.ok && data.success) {
      _showSpStatus('✅ ' + (data.message || 'Site atualizado com sucesso!'), 'success');
      if (slug) {
        _spCurrentSlug = slug;
        _spSlugValid = true;
        _updateUrlPreview(slug);
      }
    } else {
      _showSpStatus('❌ ' + (data.message || 'Erro ao salvar. Tente novamente.'), 'error');
    }
  } catch (e) {
    _showSpStatus('❌ Erro de conexão. Tente novamente.', 'error');
  } finally {
    if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = '💾 Salvar configurações'; }
  }
}

function _showSpStatus(msg, type) {
  const el = document.getElementById('sp-status-msg');
  if (!el) return;
  el.className = 'sp-status-msg ' + type;
  el.textContent = msg;
  el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function _hideSpStatus() {
  const el = document.getElementById('sp-status-msg');
  if (el) { el.className = 'sp-status-msg'; el.textContent = ''; }
}

// Expor funções Site de Promoções
window.openSitePromoModal = openSitePromoModal;
window.closeSitePromoModal = closeSitePromoModal;
window.checkSlugAvailability = checkSlugAvailability;
window.onSlugInput = onSlugInput;
window.saveSitePromoConfig = saveSitePromoConfig;
window.copySitePromoUrl = copySitePromoUrl;
window.viewSitePromo = viewSitePromo;

