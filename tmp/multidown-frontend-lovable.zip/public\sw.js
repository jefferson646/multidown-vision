// MultiDown Web - Service Worker
const CACHE_NAME = 'multidown-v1';

// Arquivos estáticos para cache offline
const STATIC_ASSETS = [
  '/login.html',
  '/icons/icon.svg',
  '/manifest.json',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Network-first para APIs, cache-first para assets estáticos
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Não interceptar requisições de API
  if (url.pathname.startsWith('/api/')) return;

  // Para assets estáticos: network-first com fallback de cache
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Armazenar em cache apenas respostas OK de assets estáticos
        if (response.ok && ['image', 'font', 'style', 'script'].includes(event.request.destination)) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
