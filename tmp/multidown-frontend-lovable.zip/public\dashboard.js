// Dashboard API Integration
let currentUser = null;
let onboardingState = null;
let onboardingStartTracked = false;
let nudgeVisible = false;
let nudgeTrigger = null;
let inactivityTimer = null;
let inactivityBound = false;

const NUDGE_LAST_SHOWN_KEY = 'md_last_nudge';
const NUDGE_COOLDOWN_HOURS = 24;
const NUDGE_INACTIVITY_MS = 5 * 60 * 1000;

// Carregar dados do usuário
async function loadUserData() {
  try {
    const response = await fetch('/api/auth/me', {
      credentials: 'include',
    });

    if (!response.ok) {
      window.location.href = '/login.html';
      return;
    }

    const data = await response.json();
    currentUser = data.user;

    // Atualizar informações do usuário
    document.getElementById('userName').textContent = currentUser.username || currentUser.first_name;

    // Atualizar foto do usuário
    const userPhoto = document.getElementById('userPhoto');
    const userInitial = document.getElementById('userInitial');

    if (currentUser.photo_url) {
      userPhoto.src = '/api/proxy/img?url=' + encodeURIComponent(currentUser.photo_url);
      userPhoto.style.display = 'block';
      userInitial.style.display = 'none';
    } else {
      const initial = (currentUser.first_name || currentUser.username || '?')[0].toUpperCase();
      userInitial.textContent = initial;
    }

    const vipBadge = document.getElementById('userBadge');
    const premiumExpiry = document.getElementById('premiumExpiry');

    if (currentUser.is_vip) {
      vipBadge.style.display = 'inline-flex';
      vipBadge.innerHTML = '<span>👑</span><span>VIP</span>';

      // Mostrar data de vencimento se houver
      if (currentUser.premium_until) {
        const expiryDate = new Date(currentUser.premium_until);
        const now = new Date();
        const daysLeft = Math.ceil((expiryDate - now) / (1000 * 60 * 60 * 24));

        if (daysLeft > 0) {
          premiumExpiry.textContent = `VIP até ${expiryDate.toLocaleDateString('pt-BR')} (${daysLeft} dias restantes)`;
          premiumExpiry.style.display = 'block';
        } else {
          premiumExpiry.textContent = 'VIP expirado';
          premiumExpiry.style.display = 'block';
          premiumExpiry.style.color = '#FFD400';
        }
      }
    } else {
      vipBadge.style.display = 'none';
      premiumExpiry.style.display = 'none';
    }

    // Configurar UI de acordo com plano do usuário
    setupPlanUI(currentUser.is_vip);

    // Carregar estatísticas
    loadStatistics();

    // Carregar downloads recentes
    loadRecentDownloads();
    // Inicializar onboarding guiado
    initOnboarding().catch((err) => console.error('Erro no onboarding:', err));

  } catch (err) {
    console.error('Erro ao carregar dados do usuário:', err);
    window.location.href = '/login.html';
  }
}

function trackOnboardingEvent(eventName, context = {}) {
  if (!window.funnelTracker) return;
  window.funnelTracker.track(eventName, context);
}

function getLastNudgeAt() {
  try {
    return parseInt(localStorage.getItem(NUDGE_LAST_SHOWN_KEY) || '0', 10) || 0;
  } catch {
    return 0;
  }
}

function setLastNudgeNow() {
  try {
    localStorage.setItem(NUDGE_LAST_SHOWN_KEY, String(Date.now()));
  } catch {
    // no-op
  }
}

function hoursSince(epochMs) {
  if (!epochMs) return Number.POSITIVE_INFINITY;
  return (Date.now() - epochMs) / 36e5;
}

function canShowNudge() {
  return hoursSince(getLastNudgeAt()) >= NUDGE_COOLDOWN_HOURS;
}

async function fetchOnboardingProgress() {
  const response = await fetch('/api/onboarding/progress', {
    credentials: 'include',
  });
  if (!response.ok) throw new Error('Falha ao carregar onboarding');
  const data = await response.json();
  return data.progress;
}

async function updateOnboardingProgress(payload) {
  const response = await fetch('/api/onboarding/progress', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-Token': getCsrfToken(),
    },
    credentials: 'include',
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error('Falha ao atualizar onboarding');
  const data = await response.json();
  return data.progress;
}

function getCsrfToken() {
  const match = document.cookie.match(/(?:^|;\s*)csrf_token=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : '';
}

function renderOnboarding(state) {
  const overlay = document.getElementById('onboarding-overlay');
  if (!overlay) return;

  const done = new Set((state?.stepsCompleted || []).map((s) => String(s)));
  [1, 2, 3].forEach((step) => {
    const item = document.getElementById(`onboarding-step-${step}`);
    if (!item) return;
    item.classList.toggle('is-done', done.has(String(step)));
  });
}

function hideNudge() {
  const nudge = document.getElementById('onboarding-nudge');
  if (!nudge) return;
  nudge.style.display = 'none';
  nudgeVisible = false;
}

function showOnboardingOverlay(source = 'dashboard_overlay') {
  const overlay = document.getElementById('onboarding-overlay');
  if (!overlay) return;
  overlay.style.display = 'flex';

  if (!onboardingStartTracked) {
    onboardingStartTracked = true;
    trackOnboardingEvent('onboarding_start', { source });
  }
}

function showNudge({ trigger, dismissedHoursAgo = null } = {}) {
  if (!canShowNudge() || nudgeVisible) return;
  const nudge = document.getElementById('onboarding-nudge');
  if (!nudge) return;

  nudge.style.display = 'block';
  nudgeVisible = true;
  nudgeTrigger = trigger || 'unknown';
  setLastNudgeNow();

  trackOnboardingEvent('nudge_shown', {
    trigger: nudgeTrigger,
    step: onboardingState?.currentStep || 1,
    dismissed_hours_ago: dismissedHoursAgo,
  });
}

function bindInactivityWatcher() {
  if (inactivityBound) return;
  inactivityBound = true;

  const resetTimer = () => {
    if (onboardingState?.completedAt) return;
    clearTimeout(inactivityTimer);
    inactivityTimer = setTimeout(() => {
      if (!nudgeVisible && onboardingState?.dismissedAt) {
        showNudge({ trigger: 'inactivity_5min' });
      }
    }, NUDGE_INACTIVITY_MS);
  };

  ['click', 'keydown', 'scroll', 'touchstart', 'mousemove'].forEach((eventName) => {
    window.addEventListener(eventName, resetTimer, { passive: true });
  });

  resetTimer();
}

function openStep(step) {
  if (step === 1) {
    const btn = document.getElementById('btn-whatsapp-connect');
    if (btn) btn.click();
    return;
  }
  if (step === 2) {
    if (typeof openConfigModal === 'function') {
      openConfigModal();
    } else {
      window.location.href = '/dashboard.html?openConfig=ml';
    }
    return;
  }
  window.location.href = '/painel-divulgacoes.html?onboarding=1';
}

function shouldShowOnboarding(state) {
  if (!state) return false;
  if (state.completedAt) return false;
  if (state.dismissedAt) return false;
  return true;
}

async function completeOnboardingStep(step) {
  onboardingState = await updateOnboardingProgress({ action: 'advance', step });
  renderOnboarding(onboardingState);
  trackOnboardingEvent('onboarding_step_complete', { step });
}

async function initOnboarding() {
  onboardingState = await fetchOnboardingProgress();

  const overlay = document.getElementById('onboarding-overlay');
  const dismissBtn = document.getElementById('onboarding-dismiss-btn');
  const completeBtn = document.getElementById('onboarding-complete-btn');
  const nudge = document.getElementById('onboarding-nudge');
  const nudgeCloseBtn = document.getElementById('onboarding-nudge-close');
  const nudgeCtaBtn = document.getElementById('onboarding-nudge-cta');
  const stepButtons = Array.from(document.querySelectorAll('[data-step-action]'));
  if (!overlay || !dismissBtn || !completeBtn || !nudge || !nudgeCloseBtn || !nudgeCtaBtn) return;

  renderOnboarding(onboardingState);

  nudgeCloseBtn.onclick = () => {
    hideNudge();
    trackOnboardingEvent('nudge_clicked', {
      action: 'close',
      trigger: nudgeTrigger || 'unknown',
      step: onboardingState?.currentStep || 1,
    });
  };

  nudgeCtaBtn.onclick = () => {
    hideNudge();
    trackOnboardingEvent('nudge_clicked', {
      action: 'resume',
      trigger: nudgeTrigger || 'unknown',
      step: onboardingState?.currentStep || 1,
    });
    showOnboardingOverlay('resume_nudge');
  };

  if (!shouldShowOnboarding(onboardingState)) {
    overlay.style.display = 'none';
    if (onboardingState?.completedAt) {
      hideNudge();
      return;
    }

    if (onboardingState?.dismissedAt) {
      const dismissedAtMs = new Date(onboardingState.dismissedAt).getTime();
      const dismissedHoursAgo = Math.floor(hoursSince(dismissedAtMs));
      if (dismissedHoursAgo >= 24) {
        showNudge({ trigger: 'return_visit_24h', dismissedHoursAgo });
      } else {
        bindInactivityWatcher();
      }
    }
    return;
  }

  hideNudge();
  showOnboardingOverlay('dashboard_overlay');

  dismissBtn.onclick = async () => {
    onboardingState = await updateOnboardingProgress({ action: 'dismiss' });
    overlay.style.display = 'none';
    trackOnboardingEvent('nudge_clicked', { action: 'dismiss_overlay', step: onboardingState?.currentStep || 1 });
    bindInactivityWatcher();
  };

  completeBtn.onclick = async () => {
    onboardingState = await updateOnboardingProgress({ action: 'complete' });
    overlay.style.display = 'none';
    hideNudge();
    trackOnboardingEvent('onboarding_complete', { source: 'manual_complete' });
  };

  stepButtons.forEach((btn) => {
    btn.onclick = async () => {
      const step = Number(btn.dataset.stepAction);
      if (!Number.isInteger(step)) return;

      await completeOnboardingStep(step);
      trackOnboardingEvent('nudge_clicked', { action: 'step_open', step });
      openStep(step);

      if (step === 3) {
        onboardingState = await updateOnboardingProgress({ action: 'complete' });
        overlay.style.display = 'none';
        hideNudge();
        trackOnboardingEvent('onboarding_complete', { source: 'step_3' });
      }
    };
  });
}

// Carregar estatísticas
async function loadStatistics() {
  try {
    const response = await fetch('/api/downloads?limit=100', {
      credentials: 'include',
    });

    if (!response.ok) {
      console.error('Erro ao carregar estatísticas');
      return;
    }

    const data = await response.json();
    const downloads = data.downloads;

    // Total de downloads
    const totalDownloads = downloads.length;
    document.getElementById('totalDownloads').textContent = totalDownloads;

    // Calcular crescimento do mês
    const thisMonth = new Date().getMonth();
    const thisMonthDownloads = downloads.filter(d =>
      new Date(d.created_at).getMonth() === thisMonth
    ).length;

    const lastMonthDownloads = downloads.filter(d =>
      new Date(d.created_at).getMonth() === thisMonth - 1
    ).length;

    if (lastMonthDownloads > 0) {
      const growth = Math.round(((thisMonthDownloads - lastMonthDownloads) / lastMonthDownloads) * 100);
      document.getElementById('downloadGrowth').textContent = `+${growth}% este mês`;
    }

    // Mensagens agendadas — buscar da API
    try {
      const schedResp = await fetch('/api/scheduling/stats', { credentials: 'include' });
      if (schedResp.ok) {
        const schedData = await schedResp.json();
        const pending = parseInt(schedData.stats?.pending || 0);
        const total = parseInt(schedData.stats?.total || 0);
        document.getElementById('scheduledMessages').textContent = total;
        document.getElementById('messagesGrowth').textContent = pending > 0 ? `+${pending} pendentes` : '+0 hoje';
      }
    } catch (e) { /* silently skip if scheduling not accessible */ }

    // Armazenamento usado
    const totalSize = downloads
      .filter(d => d.status === 'completed' && d.filesize)
      .reduce((sum, d) => sum + parseInt(d.filesize || 0), 0);

    const sizeInGB = (totalSize / (1024 * 1024 * 1024)).toFixed(1);
    document.getElementById('storageUsed').textContent = `${sizeInGB} GB`;

    const storageLimit = currentUser.is_vip ? 100 : 5;
    const storageAvailable = storageLimit - parseFloat(sizeInGB);
    document.getElementById('storageAvailable').textContent = `${storageAvailable.toFixed(1)} GB disponível`;

    // Downloads ativos
    const activeDownloads = downloads.filter(d =>
      d.status === 'queued' || d.status === 'processing'
    ).length;
    document.getElementById('activeDownloads').textContent = activeDownloads;

    if (activeDownloads === 0) {
      document.getElementById('activeStatus').textContent = '— nenhum em fila';
    } else {
      document.getElementById('activeStatus').textContent = `— ${activeDownloads} em andamento`;
    }

  } catch (err) {
    console.error('Erro ao carregar estatísticas:', err);
  }
}

// Carregar downloads recentes
async function loadRecentDownloads() {
  try {
    const response = await fetch('/api/downloads?limit=10', {
      credentials: 'include',
    });

    if (!response.ok) {
      console.error('Erro ao carregar downloads');
      return;
    }

    const data = await response.json();
    const downloads = data.downloads;

    const container = document.getElementById('downloadsList');

    if (downloads.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 40px; color: var(--text-gray);">
          <p style="font-size: 18px; margin-bottom: 8px;">📭 Nenhum download ainda</p>
          <p style="font-size: 14px;">Clique em "Novo Download" para começar!</p>
        </div>
      `;
      return;
    }

    container.innerHTML = downloads.map(download => createDownloadCard(download)).join('');

  } catch (err) {
    console.error('Erro ao carregar downloads:', err);
  }
}

// Criar card de download
function createDownloadCard(download) {
  const statusIcons = {
    completed: '✅',
    processing: '⏳',
    queued: '📋',
    failed: '❌',
    cancelled: '⚠️',
  };

  const statusColors = {
    completed: '#10B981',
    processing: '#F59E0B',
    queued: '#3B82F6',
    failed: '#EF4444',
    cancelled: '#6B7280',
  };

  const platformIcons = {
    youtube: '🎥',
    instagram: '📷',
    tiktok: '🎵',
    twitter: '🐦',
    facebook: '📘',
  };

  const icon = statusIcons[download.status] || '📥';
  const color = statusColors[download.status] || '#6B7280';
  const platform = download.platform?.toLowerCase() || 'unknown';
  const platformIcon = platformIcons[platform] || '🌐';

  const fileSize = download.filesize
    ? formatBytes(download.filesize)
    : (download.filesize_estimate ? `~${formatBytes(download.filesize_estimate)}` : '—');

  const duration = download.completed_at
    ? calculateDuration(download.created_at, download.completed_at)
    : '—';

  return `
    <div class="download-item">
      <div class="download-icon">
        ${platformIcon}
      </div>
      <div class="download-info">
        <div class="download-header">
          <h3>${download.title || 'Carregando...'}</h3>
          <span class="platform-badge" style="background: ${color}20; color: ${color}">
            ${platform.toUpperCase()}
          </span>
        </div>
        <div class="download-meta">
          <span class="meta-item">📦 ${fileSize}</span>
          <span class="meta-item">⏱️ Há ${getTimeAgo(download.created_at)}</span>
          ${download.status === 'completed' ? `<span class="meta-item">⚡ ${duration}</span>` : ''}
        </div>
      </div>
      <div class="download-actions">
        <span class="download-status" style="color: ${color}">
          ${icon} ${download.status === 'completed' ? 'Concluído' :
             download.status === 'processing' ? 'Processando' :
             download.status === 'queued' ? 'Na fila' :
             download.status === 'failed' ? 'Falhou' : 'Cancelado'}
        </span>
        ${download.status === 'completed' ? `
          <a href="/api/downloads/${download.download_id}/file"
             class="btn-download"
             download="${download.filename}">
            💾 Baixar
          </a>
        ` : ''}
        ${download.status === 'processing' || download.status === 'queued' ? `
          <span style="font-size: 12px; color: var(--text-gray);">
            ${Math.round(download.progress || 0)}%
          </span>
        ` : ''}
      </div>
    </div>
  `;
}

// Função auxiliar: formatar bytes
function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

// Função auxiliar: tempo decorrido
function getTimeAgo(date) {
  const seconds = Math.floor((new Date() - new Date(date)) / 1000);

  const intervals = {
    ano: 31536000,
    mês: 2592000,
    semana: 604800,
    dia: 86400,
    hora: 3600,
    minuto: 60,
  };

  for (const [name, value] of Object.entries(intervals)) {
    const interval = Math.floor(seconds / value);
    if (interval >= 1) {
      return `${interval} ${name}${interval > 1 ? (name === 'mês' ? 'es' : 's') : ''}`;
    }
  }

  return 'agora';
}

// Função auxiliar: duração do download
function calculateDuration(start, end) {
  const seconds = Math.floor((new Date(end) - new Date(start)) / 1000);

  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}min`;

  const hours = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  return `${hours}h ${mins}min`;
}

// Configurar UI de acordo com plano (free ou VIP)
function setupPlanUI(isVip) {
  const flashBanner = document.querySelector('.flash-banner');

  if (isVip) {
    // VIP: esconde banner de oferta
    if (flashBanner) flashBanner.style.display = 'none';
    return;
  }

  // FREE: bloquear botões de features VIP
  const vipFeatures = [
    { id: 'btn-agendar-mensagem', label: 'Agendar Mensagem' },
    { id: 'btn-clone-grupo', label: 'Clone de Grupos' },
    { id: 'btn-whatsapp-connect', label: 'Conectar WhatsApp' },
  ];

  vipFeatures.forEach(({ id, label }) => {
    const btn = document.getElementById(id);
    if (!btn) return;

    // Estilo de bloqueado
    btn.style.opacity = '0.5';
    btn.style.cursor = 'not-allowed';
    btn.style.pointerEvents = 'none';
    btn.setAttribute('aria-disabled', 'true');
    btn.setAttribute('title', `${label} requer plano VIP`);

    // Troca badge por cadeado
    const badge = btn.querySelector('.action-badge');
    if (badge) {
      badge.textContent = '🔒 VIP';
      badge.style.background = '#6b7280';
    }

    // Redirecionar para pricing ao clicar (via wrapper)
    btn.style.pointerEvents = 'auto';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.href = '/pricing.html';
    });
  });

  // Atualizar texto do banner para 9,90
  const bannerText = flashBanner?.querySelector('p');
  if (bannerText) {
    bannerText.textContent = 'Faça upgrade e ganhe downloads ilimitados por apenas R$ 9,90/mês!';
  }
}

// Logout
async function logout() {
  try {
    await fetch('/api/auth/logout', {
      method: 'POST',
      credentials: 'include',
    });
  } catch (err) {
    console.error('Erro ao fazer logout:', err);
  } finally {
    window.location.href = '/';
  }
}

// Atualizar automaticamente a cada 10 segundos
setInterval(() => {
  loadRecentDownloads();
  loadStatistics();
}, 10000);

// Inicializar ao carregar a página
document.addEventListener('DOMContentLoaded', loadUserData);
