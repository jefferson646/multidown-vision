// MultiDown Mobile - Carregamento de dados reais

async function logout() {
  try {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
  } finally {
    window.location.href = '/login-mobile.html';
  }
}

// Carregar dados ao iniciar
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Verificar autenticação
    const authRes = await fetch('/api/auth/me', { credentials: 'include' });
    if (!authRes.ok) {
      window.location.href = '/login-mobile.html';
      return;
    }

    const { user } = await authRes.json();

    // Carregar downloads
    const dlRes = await fetch('/api/downloads?limit=20', { credentials: 'include' });
    if (dlRes.ok) {
      const { downloads } = await dlRes.json();

      // Atualizar stats
      document.querySelector('[class*="Total Downloads"] + div p').textContent = downloads.length;

      const active = downloads.filter(d => d.status === 'processing' || d.status === 'queued').length;
      document.querySelector('[class*="Active Jobs"] + div p').textContent = active;

      // Atualizar lista se houver downloads
      if (downloads.length > 0) {
        updateDownloadsList(downloads.slice(0, 3));
      }
    }

  } catch (err) {
    console.error('Erro:', err);
  }
});

function updateDownloadsList(downloads) {
  const container = document.querySelector('main .space-y-4');
  if (!container) return;

  const cards = container.querySelectorAll('.bg-white');
  downloads.forEach((download, i) => {
    if (cards[i]) {
      updateCard(cards[i], download);
    }
  });
}

function updateCard(card, download) {
  // Atualizar título
  const title = card.querySelector('h4');
  if (title) title.textContent = download.title || 'Sem título';

  // Atualizar tamanho
  const size = card.querySelector('.text-\\[11px\\]');
  if (size) {
    const fileSize = download.filesize || download.filesize_estimate;
    const sizeText = fileSize ? formatBytes(fileSize) : '—';
    size.textContent = `${sizeText} • ${(download.platform || 'unknown').toUpperCase()}`;
  }

  // Atualizar status
  const badge = card.querySelector('.inline-flex');
  if (badge && download.status) {
    const statusMap = {
      completed: { class: 'bg-green-100 text-green-700', text: 'SUCCESS' },
      processing: { class: 'bg-orange-100 text-primary', text: `${Math.round(download.progress || 0)}% DOWNLOADING` },
      queued: { class: 'bg-blue-100 text-blue-700', text: 'QUEUED' },
      failed: { class: 'bg-red-100 text-red-700', text: 'FAILED' },
    };

    const status = statusMap[download.status] || statusMap.queued;
    badge.className = `inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${status.class}`;
    badge.textContent = status.text;
  }

  // Atualizar botão de download
  if (download.status === 'completed') {
    const btn = card.querySelector('.w-8.h-8');
    if (btn) {
      btn.onclick = () => window.location.href = `/api/downloads/${download.id}/file`;
    }
  }
}

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

// Auto refresh
setInterval(async () => {
  if (document.visibilityState === 'visible') {
    try {
      const res = await fetch('/api/downloads?limit=3', { credentials: 'include' });
      if (res.ok) {
        const { downloads } = await res.json();
        updateDownloadsList(downloads);
      }
    } catch (err) {
      console.error('Erro ao atualizar:', err);
    }
  }
}, 5000);
