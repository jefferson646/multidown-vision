(function initFunnelTracking() {
  const STORAGE_KEY = 'md_anon_id';

  function uuid() {
    if (window.crypto && window.crypto.randomUUID) {
      return window.crypto.randomUUID();
    }
    return `anon_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }

  function getAnonymousId() {
    try {
      let id = localStorage.getItem(STORAGE_KEY);
      if (!id) {
        id = uuid();
        localStorage.setItem(STORAGE_KEY, id);
      }
      return id;
    } catch {
      return `anon_${Date.now()}`;
    }
  }

  function getUtmContext() {
    const params = new URLSearchParams(window.location.search);
    return {
      utm_source: params.get('utm_source'),
      utm_medium: params.get('utm_medium'),
      utm_campaign: params.get('utm_campaign'),
      utm_content: params.get('utm_content'),
      utm_term: params.get('utm_term'),
    };
  }

  function send(payload) {
    const body = JSON.stringify(payload);

    if (navigator.sendBeacon) {
      const blob = new Blob([body], { type: 'application/json' });
      navigator.sendBeacon('/api/funnel/events', blob);
      return;
    }

    fetch('/api/funnel/events', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      credentials: 'include',
      keepalive: true,
    }).catch(() => {});
  }

  function track(eventName, context = {}) {
    send({
      eventName,
      anonymousId: getAnonymousId(),
      pagePath: window.location.pathname,
      source: document.referrer ? new URL(document.referrer, window.location.origin).hostname : null,
      referrer: document.referrer || null,
      context: {
        ...getUtmContext(),
        ...context,
      },
    });
  }

  window.funnelTracker = {
    track,
  };
})();

