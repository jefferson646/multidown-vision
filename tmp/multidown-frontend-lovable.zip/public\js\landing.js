document.addEventListener('DOMContentLoaded', () => {
  if (window.funnelTracker) {
    window.funnelTracker.track('view_landing', {
      page_variant: 'main_v1',
    });
  }

  document.querySelectorAll('[data-track-cta]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (!window.funnelTracker) return;
      window.funnelTracker.track('click_cta', {
        cta_name: btn.dataset.trackCta,
        cta_text: btn.textContent.trim(),
        destination: btn.getAttribute('href') || null,
      });
    });
  });
});

