// MultiDown Mobile App - JavaScript

let currentUser = null;

// Carregar dados do usuário
async function loadUserData() {
  try {
    const response = await fetch('/api/auth/me', {
      credentials: 'include',
    });

    if (!response.ok) {
      window.location.href = '/login-mobile.html';
      return;
    }

    const data = await response.json();
    currentUser = data.user;

    // Atualizar header
    const userName = document.getElementById('userName');
    const userAvatar = document.getElementById('userAvatar');
    const vipBadge = document.getElementById('vipBadge');

    if (userName) {
      userName.textContent = currentUser.username || currentUser.first_name;
    }

    if (userAvatar) {
      userAvatar.textContent = (currentUser.username || currentUser.first_name || '?')[0].toUpperCase();
    }

    if (vipBadge && currentUser.is_vip) {
      vipBadge.classList.remove('hidden');
    }

    // Carregar dados
    await Promise.all([
      loadStats(),
      loadDownloads()
    ]);

  } catch (err) {
    console.error('Erro ao carregar dados:', err);
    window.location.href = '/login-mobile.html';
  }
}

// Carregar estatísticas
async function loadStats() {
  try {
    const response = await fetch('/api/downloads?limit=100', {
      credentials: 'include',
    });

    if (!response.ok) return;

    const data = await response.json();
    const downloads = data.downloads;

    // Total
    document.getElementById('totalDownloads').textContent = downloads.length;

    // Crescimento
    const thisMonth = new Date().getMonth();
    const thisMonthCount = downloads.filter(d =>
      new Date(d.created_at).getMonth() === thisMonth
    ).length;
    document.getElementById('downloadGrowth').textContent = `+${thisMonthCount}`;

    // Armazenamento
    const totalSize = downloads
      .filter(d => d.status === 'completed' && d.filesize)
      .reduce((sum, d) => sum + parseInt(d.filesize || 0), 0);

    const sizeGB = (totalSize / (1024 * 1024 * 1024));
    const limit = currentUser?.is_vip ? 100 : 5;
    const percent = Math.min(Math.round((sizeGB / limit) * 100), 100);

    document.getElementById('storagePercent').textContent = `${percent}%`;
    document.getElementById('storageBar').style.width = `${percent}%`;

    // Ativos
    const active = downloads.filter(d =>
      d.status === 'queued' || d.status === 'processing'
    ).length;
    document.getElementById('activeJobs').textContent = active;

  } catch (err) {
    console.error('Erro ao carregar stats:', err);
  }
}

// Carregar downloads
async function loadDownloads() {
  try {
    const response = await fetch('/api/downloads?limit=10', {
      credentials: 'include',
    });

    if (!response.ok) return;

    const data = await response.json();
    const container = document.getElementById('downloadsList');

    if (data.downloads.length === 0) {
      container.innerHTML = `
        <div class="text-center py-12">
          <span class="material-symbols-outlined text-6xl text-gray-300">download</span>
          <p class="text-gray-400 mt-4">Nenhum download ainda</p>
          <p class="text-sm text-gray-400">Clique no + para começar</p>
        </div>
      `;
      return;
    }

    container.innerHTML = data.downloads.map(d => createDownloadCard(d)).join('');

  } catch (err) {
    console.error('Erro ao carregar downloads:', err);
  }
}

// Criar card de download
function createDownloadCard(download) {
  const statusConfig = {
    completed: {
      badge: 'bg-green-100 text-green-700',
      label: 'SUCCESS',
      icon: 'download',
      btnClass: 'bg-primary/10 text-primary',
    },
    processing: {
      badge: 'bg-orange-100 text-primary',
      label: `${Math.round(download.progress || 0)}% DOWNLOADING`,
      icon: 'sync',
      btnClass: 'bg-gray-100 text-gray-500',
    },
    queued: {
      badge: 'bg-blue-100 text-blue-700',
      label: 'QUEUED',
      icon: 'schedule',
      btnClass: 'bg-gray-100 text-gray-500',
    },
    failed: {
      badge: 'bg-red-100 text-red-700',
      label: 'FAILED',
      icon: 'error',
      btnClass: 'bg-red-100 text-red-600',
    },
  };

  const config = statusConfig[download.status] || statusConfig.queued;
  const platformIcons = {
    youtube: 'play_circle',
    tiktok: 'music_note',
    instagram: 'photo_camera',
    twitter: 'tag',
    facebook: 'movie',
  };

  const platformIcon = platformIcons[download.platform] || 'videocam';
  const fileSize = download.filesize || download.filesize_estimate;
  const sizeText = fileSize ? formatBytes(fileSize) : '—';

  return `
    <div class="bg-white dark:bg-white/5 rounded-xl p-3 shadow-sm flex gap-4 border border-primary/5">
      <div class="relative w-32 h-20 shrink-0 overflow-hidden rounded-lg bg-gradient-to-br from-primary/10 to-orange-100">
        ${download.thumbnail_url ? `
          <img alt="Thumbnail" class="w-full h-full object-cover" src="${download.thumbnail_url}" onerror="this.style.display='none'">
        ` : ''}
        <div class="absolute top-1 left-1 bg-primary rounded-md p-1 leading-[0]">
          <span class="material-symbols-outlined text-white text-[16px]">${platformIcon}</span>
        </div>
        ${download.status === 'processing' ? `
          <div class="absolute inset-0 flex items-center justify-center bg-black/20">
            <span class="material-symbols-outlined text-white animate-spin">${config.icon}</span>
          </div>
          <div class="absolute bottom-0 left-0 right-0 h-1 bg-gray-200">
            <div class="h-full bg-primary transition-all" style="width: ${download.progress || 0}%"></div>
          </div>
        ` : ''}
      </div>
      <div class="flex flex-col justify-between flex-1 py-0.5">
        <div>
          <h4 class="text-sm font-bold leading-snug line-clamp-2">${download.title || 'Carregando...'}</h4>
          <p class="text-[11px] text-gray-500 mt-1">${sizeText} • ${download.platform.toUpperCase()}</p>
        </div>
        <div class="flex items-center justify-between mt-2">
          <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${config.badge}">
            ${config.label}
          </span>
          ${download.status === 'completed' ? `
            <a href="/api/downloads/${download.id}/file" class="w-8 h-8 rounded-full ${config.btnClass} flex items-center justify-center">
              <span class="material-symbols-outlined text-[20px]">${config.icon}</span>
            </a>
          ` : `
            <button class="w-8 h-8 rounded-full ${config.btnClass} flex items-center justify-center">
              <span class="material-symbols-outlined text-[20px]">${config.icon}</span>
            </button>
          `}
        </div>
      </div>
    </div>
  `;
}

// Format bytes
function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

// Logout
async function logout() {
  try {
    await fetch('/api/auth/logout', {
      method: 'POST',
      credentials: 'include',
    });
  } catch (err) {
    console.error('Erro ao fazer logout:', err);
  } finally {
    window.location.href = '/login-mobile.html';
  }
}

// Auto refresh
setInterval(() => {
  if (document.visibilityState === 'visible') {
    loadStats();
    loadDownloads();
  }
}, 5000);

// Init
document.addEventListener('DOMContentLoaded', loadUserData);
