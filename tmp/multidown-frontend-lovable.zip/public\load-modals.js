// Carregar modals dinamicamente
async function loadModals() {
  try {
    // Carregar modal WhatsApp
    const waResponse = await fetch('/modal-whatsapp.html');
    const waHtml = await waResponse.text();

    // Carregar modal Agendamento
    const agendaResponse = await fetch('/modal-agendamento.html');
    const agendaHtml = await agendaResponse.text();

    // Carregar modal Configurações
    const configResponse = await fetch('/modal-configuracoes.html');
    const configHtml = await configResponse.text();

    // Carregar modal Clone de Grupos
    const cloneResponse = await fetch('/modal-clone-grupo.html');
    const cloneHtml = await cloneResponse.text();

    // Carregar modal Buscar Produtos
    const searchResponse = await fetch('/modal-buscar-produtos.html');
    const searchHtml = await searchResponse.text();

    // Carregar modal Telegram
    const telegramResponse = await fetch('/modal-telegram.html');
    const telegramHtml = await telegramResponse.text();

    // Carregar modal Site de Promoções
    const sitePromoResponse = await fetch('/modal-site-promocoes.html');
    const sitePromoHtml = await sitePromoResponse.text();

    // Usar DOMParser para extrair apenas HTML e CSS (sem scripts)
    function extractHtmlWithoutScripts(html) {
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, 'text/html');

      // Remover todos os scripts
      doc.querySelectorAll('script').forEach(s => s.remove());

      // Retornar o HTML do body (sem scripts)
      return doc.body.innerHTML;
    }

    const cleanWaHtml = extractHtmlWithoutScripts(waHtml);
    const cleanAgendaHtml = extractHtmlWithoutScripts(agendaHtml);
    const cleanConfigHtml = extractHtmlWithoutScripts(configHtml);
    const cleanCloneHtml = extractHtmlWithoutScripts(cloneHtml);
    const cleanSearchHtml = extractHtmlWithoutScripts(searchHtml);
    const cleanTelegramHtml = extractHtmlWithoutScripts(telegramHtml);
    const cleanSitePromoHtml = extractHtmlWithoutScripts(sitePromoHtml);

    // Remover modals antigos se existirem
    const oldWaModal = document.getElementById('modal-whatsapp');
    if (oldWaModal && oldWaModal.parentElement) {
      oldWaModal.parentElement.removeChild(oldWaModal);
    }

    const oldAgendaModal = document.getElementById('modal-agendamento');
    if (oldAgendaModal && oldAgendaModal.parentElement) {
      oldAgendaModal.parentElement.removeChild(oldAgendaModal);
    }

    const oldConfigModal = document.getElementById('modal-configuracoes');
    if (oldConfigModal && oldConfigModal.parentElement) {
      oldConfigModal.parentElement.removeChild(oldConfigModal);
    }

    const oldCloneModal = document.getElementById('modal-clone-grupo');
    if (oldCloneModal && oldCloneModal.parentElement) {
      oldCloneModal.parentElement.removeChild(oldCloneModal);
    }

    const oldSearchModal = document.getElementById('modal-buscar-produtos');
    if (oldSearchModal && oldSearchModal.parentElement) {
      oldSearchModal.parentElement.removeChild(oldSearchModal);
    }

    const oldTelegramModal = document.getElementById('modal-telegram');
    if (oldTelegramModal && oldTelegramModal.parentElement) {
      oldTelegramModal.parentElement.removeChild(oldTelegramModal);
    }

    const oldSitePromoModal = document.getElementById('modal-site-promocoes');
    if (oldSitePromoModal && oldSitePromoModal.parentElement) {
      oldSitePromoModal.parentElement.removeChild(oldSitePromoModal);
    }

    // Inserir novos modals no body (sem scripts)
    document.body.insertAdjacentHTML('beforeend', cleanWaHtml);
    document.body.insertAdjacentHTML('beforeend', cleanAgendaHtml);
    document.body.insertAdjacentHTML('beforeend', cleanConfigHtml);
    document.body.insertAdjacentHTML('beforeend', cleanCloneHtml);
    document.body.insertAdjacentHTML('beforeend', cleanSearchHtml);
    document.body.insertAdjacentHTML('beforeend', cleanTelegramHtml);
    document.body.insertAdjacentHTML('beforeend', cleanSitePromoHtml);
    console.log('✅ Modais carregados com sucesso!');

    // Carregar e executar handlers após inserir HTML
    loadModalHandlers();

  } catch (error) {
    console.error('❌ Erro ao carregar modais:', error);
  }
}

// Carregar arquivo de handlers JavaScript
function loadModalHandlers() {
  // Criar novo script tag
  const script = document.createElement('script');
  script.id = 'modal-handlers-script';
  script.src = '/modal-handlers.js?v=' + Date.now(); // Cache bust
  script.onload = () => {
    console.log('✅ Handlers carregados e inicializados!');
  };
  script.onerror = () => {
    console.error('❌ Erro ao carregar modal-handlers.js');
  };

  document.body.appendChild(script);
}

// Carregar ao inicializar
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', loadModals);
} else {
  loadModals();
}
